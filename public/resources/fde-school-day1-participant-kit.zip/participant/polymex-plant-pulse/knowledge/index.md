# Polymex engagement: knowledge bundle

Single source of truth for the team's work at Polymex Industries, in the Open Knowledge Format. Every email, file, discussion and meeting recording from the engagement is captured here the same day, with consent.

## Contents

- people/: who we work with, their role and what they asked
- findings/: what the data shows, with links to the evidence
- metrics/: definitions, linked to the code that computes them
- rules/: plant rules, with their source and who validated them
- decisions/: who decided what, when, on what evidence
- meetings/: notes of every meeting, linked to recordings where they exist
- sources/: originals (emails, files, recordings), never edited

## What we found today

