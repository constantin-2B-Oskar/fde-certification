---
type: metric
title: OEE, extrusion
description: Availability x performance x quality, each computed from sums over the period
tags: [extrusion, kpi]
sources:
  - ../../data/DATA_DICTIONARY.md
status: active
---
## Computation

- Availability = sum(run_min) / sum(planned_min)
- Performance = sum(output_t) / sum(run_min / 60 x ideal_rate_tph)
- Quality = sum(output_t - scrap_t) / sum(output_t)
- OEE = availability x performance x quality

Never average per-row ratios.
