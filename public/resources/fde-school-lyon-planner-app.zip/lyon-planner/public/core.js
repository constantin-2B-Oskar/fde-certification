// Lyon Planner core: the application state and every operation on it. The same file runs in the browser (local demo)
// and in the Node server (shared team instance). Operations check the actor's permissions before they change anything.
(function (root) {
const isNode = typeof module !== 'undefined' && module.exports;
const ENG = isNode ? require('./engine.js') : root.LyonEngine;
const DATA = isNode ? require('./data.js') : root.LyonPlannerData;

const ACTORS = {
  corinne: { name: 'Corinne', role: 'Planner', grants: ['plan.run', 'plan.publish', 'plan.override', 'event.apply', 'event.whatif', 'rule.propose', 'rule.validate', 'rule.retire', 'feedback.write', 'eval.snapshot'] },
  sylvie: { name: 'Sylvie', role: 'Event desk', grants: ['event.apply', 'event.whatif', 'rule.propose', 'feedback.write', 'eval.snapshot'] },
  stephane: { name: 'Stéphane', role: 'Key accounts', grants: ['event.whatif', 'eval.snapshot'] },
  kevin: { name: 'Kevin', role: 'Night shift leader', grants: ['feedback.write', 'rule.propose', 'event.whatif'] },
  nadia: { name: 'Nadia', role: 'IT manager', grants: ['source.toggle', 'killswitch'] },
};
const SOURCES = [
  { id: 'sap', name: 'SAP ECC, SD and PP', what: 'Open orders, customers, products, promise dates', mode: 'read', refresh: 'every 15 min', owner: 'Group IT', connector: 'SAP reader, platform', enabled: true },
  { id: 'sap_wb', name: 'SAP process orders, write-back', what: 'The published plan: line, sequence, start, end', mode: 'write', refresh: 'at every publish', owner: 'Nadia', connector: 'Built with group IT', enabled: false, gated: true },
  { id: 'linelog', name: 'LineLog', what: 'What ran, stops, changeovers, comments', mode: 'read', refresh: 'CSV at 06:00', owner: 'Nadia', connector: 'File reader, platform', enabled: true },
  { id: 'lab', name: 'Lab database', what: 'Holds and releases, by batch', mode: 'read', refresh: 'nightly copy', owner: 'Amina', connector: 'Lab mapping, built for Lyon', enabled: true },
  { id: 'maintpro', name: 'MaintPro', what: 'Preventive windows, breakdowns', mode: 'read', refresh: 'every 15 min', owner: 'Patrick', connector: 'REST reader, platform', enabled: true },
  { id: 'mailbox', name: 'Planning mailbox', what: 'Customer changes, rush orders, cancellations', mode: 'read', refresh: 'live', owner: 'Stéphane', connector: 'Mailbox reader, platform', enabled: true },
  { id: 'hr', name: 'HR calendar and carriers', what: 'Holiday staffing, transport times', mode: 'read', refresh: 'monthly', owner: 'Didier, Stéphane', connector: 'File reader, platform', enabled: true },
];
const clone = (x) => JSON.parse(JSON.stringify(x));
const nowIso = () => new Date().toISOString();

function initial() {
  const s = { version: 1, mode: 'demo', killswitch: false, products: clone(DATA.products), lines: clone(DATA.lines), orders: clone(DATA.orders), rules: clone(DATA.rules), events: DATA.events.map((e) => ({ ...e, status: 'inbox' })), sources: clone(SOURCES), draft: null, published: null, feedback: [], evals: [], audit: [], horizon_start: '2026-05-11 06:00', clock: '2026-05-11 05:30' };
  const st = baseState(s); const R = compiled(s);
  const seqs = Object.fromEntries(Object.keys(s.lines).map((l) => [l, []]));
  for (const r of DATA.humanRows) seqs[r.line].push(r.order_id);
  const ev = ENG.evaluate(seqs, st, R);
  s.baseline = { kind: 'human', label: "Corinne's Friday plan", seqs, timed: ev.timed, kpis: ENG.kpis(ev, st, R), violations: ev.violations, moves: [] };
  addEval(s, s.baseline, 'system');
  return s;
}
const baseState = (s) => ({ horizon_start: s.horizon_start, lines: s.lines, orders: s.orders });
const downRules = (s) => s.events.filter((e) => e.status === 'applied' && e.type === 'machine_down').map((e) => ({ id: 'EV-' + e.event_id, type: 'blackout', params: { line: e.line, start: e.from, end: e.to }, status: 'active' }));
const compiled = (s, extra = []) => ENG.compile([...s.rules, ...downRules(s), ...extra], s.products);
function can(actor, g) { const a = ACTORS[actor]; return !!a && a.grants.includes(g); }
function need(s, actor, g) {
  if (s.killswitch && g !== 'killswitch') throw new Error('Kill switch engaged by Nadia: every change is refused.');
  if (!can(actor, g)) throw new Error((ACTORS[actor]?.name || actor) + ' may not ' + g.replace('.', ' '));
}
function log(s, actor, what, detail) { s.audit.unshift({ at: nowIso(), actor, what, detail }); s.audit = s.audit.slice(0, 300); s.version++; }

// Score of a plan, 0 to 100, and the checks behind it.
function scorePlan(s, p) {
  const k = p.kpis, base = s.baseline ? s.baseline.kpis : k;
  const HARD = ['forbidden_transition', 'line_capability', 'customer_line_qualification', 'changeover_table', 'changeover_override'];
  const hard = (p.violations || []).filter((v) => HARD.includes((s.rules.find((r) => r.id === v.rule) || {}).type)).length;
  const soft = (p.violations || []).length - hard;
  const moved = (p.moves || []).filter((m) => m.kind !== 'time').length;
  const c = {
    on_time: k.on_time_pct,
    codra: k.codra_on_time_pct ?? 100,
    changeovers: Math.max(0, Math.min(100, 50 + 100 * (base.changeover_hours - k.changeover_hours) / base.changeover_hours)),
    stability: p.kind === 'short' || p.kind === 'override' ? Math.max(0, 100 - 4 * moved) : 100,
    rules: Math.max(0, 100 - 50 * hard - 15 * soft),
  };
  const score = Math.round(0.35 * c.on_time + 0.25 * c.codra + 0.2 * c.changeovers + 0.1 * c.stability + 0.1 * c.rules);
  const checks = [
    { id: 'hard', label: 'No forbidden transition, capability or qualification broken', pass: hard === 0 },
    { id: 'soft', label: 'No dryer, shared-resource or shift-limit violation', pass: soft === 0 },
    { id: 'codra', label: 'Codra on time at 95% or more', pass: (k.codra_on_time_pct ?? 100) >= 95 },
    { id: 'ontime', label: 'All orders on time at 90% or more', pass: k.on_time_pct >= 90 },
    { id: 'co', label: 'Changeover hours below the Friday plan', pass: k.changeover_hours < base.changeover_hours || p.kind === 'human' },
    { id: 'stable', label: 'A repair moves at most 10 orders', pass: !(p.kind === 'short' || p.kind === 'override') || moved <= 10 },
    { id: 'reason', label: 'Every override has a reason', pass: s.feedback.filter((f) => f.kind === 'override').every((f) => f.text && f.text.length >= 5) },
  ];
  return { score, components: c, checks };
}
function addEval(s, p, actor, label) {
  const r = scorePlan(s, p);
  s.evals.unshift({ id: 'P' + String(s.evals.length + 1).padStart(3, '0'), at: nowIso(), label: label || p.label || p.kind, kind: p.kind, by: actor, kpis: { on_time_pct: p.kpis.on_time_pct, codra_on_time_pct: p.kpis.codra_on_time_pct, changeover_hours: p.kpis.changeover_hours, changeovers: p.kpis.changeovers, late: p.kpis.late.length, violations: (p.violations || []).length }, moves: (p.moves || []).filter((m) => m.kind !== 'time').length, ...r });
}

const OPS = {
  runDaily(s, actor, { now }) {
    need(s, actor, 'plan.run');
    const R = compiled(s); let st = baseState(s), opts = {};
    if (s.published) { const rf = ENG.rollForward(s.published, st, now, R.freezeMinutes); st = rf.state; opts = { keep: rf.keep, fixed: rf.fixed }; s.orders = st.orders; s.lines = st.lines; s.horizon_start = st.horizon_start; }
    const res = ENG.longSolve(st, R, { timeBudgetMs: 2500, ...opts });
    s.draft = { kind: 'long', label: 'Daily plan, ' + now, created_at: now, by: actor, seqs: res.seqs, timed: res.timed, kpis: res.kpis, violations: res.violations, moves: [], runtime_ms: res.runtime_ms, before: s.published ? s.published.kpis : s.baseline.kpis };
    s.clock = now; addEval(s, s.draft, actor); log(s, actor, 'Daily plan drafted', res.runtime_ms + ' ms, ' + res.kpis.on_time_pct + '% on time');
  },
  publish(s, actor) {
    need(s, actor, 'plan.publish'); if (!s.draft) throw new Error('Nothing to publish');
    s.published = { ...s.draft, published_at: nowIso(), published_by: actor }; s.draft = null;
    const wb = s.sources.find((x) => x.id === 'sap_wb'); if (wb.enabled) { wb.last = nowIso(); wb.rows = Object.values(s.published.timed).flat().length; }
    log(s, actor, 'Plan published', s.published.label + (wb.enabled ? '; written to SAP' : '; SAP write-back off'));
  },
  discard(s, actor, { reason }) { need(s, actor, 'plan.publish'); s.draft = null; if (reason) s.feedback.unshift(fb(s, 'override', actor, { text: 'Draft discarded: ' + reason })); log(s, actor, 'Draft discarded', reason || ''); },
  applyEvent(s, actor, { id, at }) {
    need(s, actor, 'event.apply'); if (!s.published) throw new Error('Publish a plan first: repairs start from the published plan.');
    const e = s.events.find((x) => x.event_id === id); if (!e || e.status === 'applied') throw new Error('Event not available');
    const evt = { ...e, at: at || e.at };
    const a = ENG.applyEvent(baseState(s), evt); const R = compiled(s, a.rulesAdded);
    const res = ENG.fastRepair(s.published, a.state, R, { now: evt.at, changed: a.changed, removed: a.removed, linesAffected: a.linesAffected, horizonHours: 48, timeBudgetMs: 800 });
    s.orders = a.state.orders; e.status = 'applied'; e.applied_by = actor; e.applied_at = evt.at;
    s.draft = { kind: 'short', label: 'Repair after ' + id + ', ' + e.type.replace('_', ' '), created_at: evt.at, by: actor, event_id: id, seqs: res.seqs, timed: res.timed, kpis: res.kpis, violations: res.violations, moves: res.moves, runtime_ms: res.runtime_ms, before: s.published.kpis };
    s.clock = evt.at; addEval(s, s.draft, actor); log(s, actor, 'Event applied, repair drafted', id + ': ' + res.runtime_ms + ' ms, ' + res.moves.filter((m) => m.kind !== 'time').length + ' orders moved');
  },
  whatIf(s, actor, { id }) {
    need(s, actor, 'event.whatif'); if (!s.published) throw new Error('Publish a plan first');
    const e = s.events.find((x) => x.event_id === id); const a = ENG.applyEvent(baseState(s), e); const R = compiled(s, a.rulesAdded);
    const res = ENG.fastRepair(s.published, a.state, R, { now: e.at, changed: a.changed, removed: a.removed, linesAffected: a.linesAffected });
    const row = a.changed[0] ? Object.values(res.timed).flat().find((r) => r.order_id === a.changed[0]) : null;
    s.lastWhatIf = { id, at: nowIso(), by: actor, order: row ? { order_id: row.order_id, line: row.line, end: ENG.fmtTime(row.end), due: row.due } : null, moved: res.moves.filter((m) => m.kind !== 'time').length, on_time: res.kpis.on_time_pct, codra: res.kpis.codra_on_time_pct };
    log(s, actor, 'What-if', id);
  },
  override(s, actor, { order_id, line, position, reason }) {
    need(s, actor, 'plan.override'); if (!reason || reason.trim().length < 5) throw new Error('An override needs a reason: it is how the rules we miss are found.');
    const base = s.draft || s.published; if (!base) throw new Error('No plan');
    const seqs = clone(base.seqs); for (const l of Object.keys(seqs)) seqs[l] = seqs[l].filter((x) => x !== order_id);
    const pos = Math.max(0, Math.min(seqs[line].length, (+position || 1) - 1)); seqs[line].splice(pos, 0, order_id);
    const st = baseState(s), R = compiled(s), ev = ENG.evaluate(seqs, st, R);
    s.draft = { kind: 'override', label: 'Override of ' + order_id + ' to ' + line, created_at: s.clock, by: actor, seqs, timed: ev.timed, kpis: ENG.kpis(ev, st, R), violations: ev.violations, moves: [{ order_id, kind: 'override', to: { line, position: pos + 1 } }], before: base.kpis };
    s.feedback.unshift(fb(s, 'override', actor, { order_id, text: reason, detail: 'Moved to ' + line + ', position ' + (pos + 1) }));
    addEval(s, s.draft, actor); log(s, actor, 'Override', order_id + ' to ' + line + ': ' + reason);
  },
  deviation(s, actor, { order_id, what, why, cls, told_by }) {
    need(s, actor, 'feedback.write'); if (!what) throw new Error('Say what happened');
    s.feedback.unshift(fb(s, 'deviation', actor, { order_id, text: what, whys: why ? [why] : [], cls: cls || 'rule missing', told_by })); log(s, actor, 'Deviation recorded', order_id + ': ' + what);
  },
  feedbackSave(s, actor, { id, whys, root, outcome, rule }) {
    need(s, actor, 'feedback.write'); const f = s.feedback.find((x) => x.id === id); if (!f) throw new Error('No item ' + id);
    f.whys = whys || f.whys; f.root = root ?? f.root;
    if (outcome) {
      if ((f.whys || []).filter(Boolean).length === 0) throw new Error('Ask at least one why before you decide.');
      f.outcome = outcome; f.status = 'closed';
      if (outcome === 'rule') { need(s, actor, 'rule.propose'); const r = newRule(s, actor, rule, f); f.rule_id = r.id; f.status = 'rule ' + r.id; }
    }
    log(s, actor, 'Feedback ' + (outcome ? 'closed as ' + outcome : 'updated'), id);
  },
  ruleAdd(s, actor, { rule }) { need(s, actor, 'rule.propose'); newRule(s, actor, rule); },
  ruleStatus(s, actor, { id, status }) {
    need(s, actor, status === 'active' ? 'rule.validate' : 'rule.retire');
    const r = s.rules.find((x) => x.id === id); if (!r) throw new Error('No rule ' + id);
    const prev = r.status; r.status = status;
    try { compiled(s); } catch (e) { r.status = prev; throw new Error('The rule does not compile: ' + e.message); }
    if (status === 'active') { r.validated_by = ACTORS[actor].name; r.validated_on = new Date().toISOString().slice(0, 10); }
    if (status === 'retired') r.retired_on = new Date().toISOString().slice(0, 10);
    log(s, actor, 'Rule ' + status, id);
  },
  sourceToggle(s, actor, { id }) { need(s, actor, 'source.toggle'); const x = s.sources.find((y) => y.id === id); x.enabled = !x.enabled; log(s, actor, (x.enabled ? 'Enabled ' : 'Disabled ') + x.name, ''); },
  killswitch(s, actor) { need(s, actor, 'killswitch'); s.killswitch = !s.killswitch; log(s, actor, s.killswitch ? 'Kill switch engaged' : 'Kill switch released', ''); },
  snapshot(s, actor) { need(s, actor, 'eval.snapshot'); const p = s.draft || s.published; if (!p) throw new Error('No plan'); addEval(s, p, actor, (s.draft ? 'Draft: ' : 'Published: ') + p.label); log(s, actor, 'Plan scored', ''); },
};
function fb(s, kind, actor, x) { return { id: (kind === 'override' ? 'OV' : 'DV') + String(s.feedback.filter((f) => f.kind === kind).length + 1).padStart(3, '0'), kind, at: nowIso(), by: actor, status: 'open', whys: [], root: '', ...x }; }
function newRule(s, actor, rule, f) {
  if (!rule || !rule.type || !rule.statement || !rule.owner) throw new Error('A rule needs a type, a statement and an owner.');
  let params = rule.params; if (typeof params === 'string') { try { params = JSON.parse(params); } catch (e) { throw new Error('Parameters are not valid JSON'); } }
  const n = Math.max(...s.rules.map((r) => parseInt(r.id.slice(1), 10) || 0)) + 1;
  const r = { id: 'R' + n, category: rule.category || 'Captured', type: rule.type, statement: rule.statement, params, source: rule.source || (ACTORS[actor].name + ', ' + new Date().toISOString().slice(0, 10)), owner: rule.owner, status: 'proposed', proposed_by: ACTORS[actor].name, discovery: f ? { from: f.id, whys: f.whys, root: f.root } : null };
  s.rules.push(r); log(s, actor, 'Rule proposed', r.id + ': ' + r.statement); return r;
}
function apply(state, op, actor, args) {
  if (!OPS[op]) throw new Error('Unknown operation ' + op);
  const s = clone(state); OPS[op](s, actor, args || {}); return s;
}
const api = { initial, apply, scorePlan, ACTORS, can, ENG, DATA };
if (isNode) module.exports = api; else root.LyonCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
