<!-- DECK: FDE School, Day 1 morning, "The job AI created". 120 slides, 9:00 to 12:00. Trainer: Renan. -->
<!-- Conventions for Claude Design: slides are separated by a line of three dashes. The first comment of each slide gives its number and type. Text inside comments is design direction, never slide text. Identity: OSS Ventures design system. Ink #0D0D0D, paper #FDFDFD, flame #FD594F as the single accent; Fjalla One uppercase titles, Inter body, Archivo labels, Geist Mono for sources and figures; brand photography only. Rendered deck: "D1 AM - Deck - The job AI created.dc.html". -->

<!-- 1 | Title -->
# FDE School
## Day 1 morning: the job AI created

FDE School, by Devoteam and OSS Ventures
Renan Devillières

*AI 50%: drafted with Claude from the FDE School curriculum and OSS field material, validated by the trainer.*

---
<!-- 2 | Hero -->
## Every company can now rent the same intelligence. Almost none can deploy it.

---
<!-- 3 | Detail -->
## This morning: meet the room, set up, learn the job, then every team ships a live app

| Time | Block | You leave with |
|---|---|---|
| 9:00 | Opening | How the week works |
| 9:08 | Round table | Who is in the room, and what they bring |
| 9:35 | Setup sprint | A laptop that builds, checks and deploys |
| 10:05 | Why the job exists | The economics of deployment |
| 10:22 | The FDE job definition | Mission, responsibilities, measures, path |
| 10:42 | Break | |
| 10:52 | The context of the role | How a plant is run, and who decides |
| 11:02 | Lab: Polymex Plant Pulse | A deployed app with checked numbers |
| 11:43 | Demos | Feedback from the room |
| 11:56 | Close | Three things to keep |

---
<!-- 4 | Detail -->
## By noon you will know the room, the job and the plant, and you will have shipped

- You know who is in your cohort and what each person brings.
- Your laptop builds, deploys and keeps secrets out of Git.
- You can say in two sentences what an FDE is accountable for, and what it is not.
- You can explain with three numbers why deployment, not the model, is where industrial AI fails.
- Your team has shipped a live app on plant data, with numbers another pair has checked.

---
<!-- 5 | Framework -->
## The week moves from the role to the business, the technology, the obstacles and the full motion

1. **The role.** What an FDE is; how consultants think and speak.
2. **The business.** Where a plant loses money; how an FDE project is run.
3. **The technology.** Plant systems and data; how AI works, and building with it.
4. **The obstacles.** Dirty data and legacy systems; people who resist.
5. **The full motion.** Two real engagements, then the FDE Certification exam.

---
<!-- 6 | Framework -->
## Four design choices make this a working week, not a course

- **One plant all week.** Polymex Industries. Every lab from Monday to Thursday happens inside it.
- **Everything lands in a deliverable.** A URL, a memo, a protocol. No exercise ends in notes.
- **AI-native.** Claude Code does most of the typing. You own the spec, the checks and the deployment.
- **Real engagements on Friday.** Disguised, then the exam.

---
<!-- 7 | Detail -->
## Two firms built this week together, and both will be in the room

| | Brings |
|---|---|
| Devoteam | The engineers, the client relationships, the delivery organization you will join |
| OSS Ventures | Twenty-two industrial software companies, the Transformer program, the field lessons in this deck |
| Renan Devillières | Days 1, 2, 4 and 5: the role, the business, the obstacles, the full motion |
| Nicolas | Day 3: plant systems, data and AI engineering |

---
<!-- 8 | Detail -->
## Five house rules keep the room safe and the clients protected

1. Chatham House: use what you hear, never attribute it.
2. Friday's cases are real and disguised. If you recognize a company, keep it to yourself and add nothing that is not in the case pack.
3. No client data in consumer AI tools, ever.
4. AI tools are unrestricted in labs and forbidden in the exam.
5. Laptops closed during teaching, open in labs.

---
<!-- 9 | Framework -->
## Teams of four, four roles, rotating every day

| Role | Owns |
|---|---|
| Lead | Scope, time, decisions, the question asked to the sponsor |
| Builder | The keyboard, Claude Code, the deployed artifact |
| Verifier | Independent checks of every number, the verification log |
| Storyteller | The memo, the storyline, the readout |

Choose today's roles at the end of the round table. Everyone holds each role at least once this week.

---
<!-- 10 | Detail -->
## How the week is assessed: feedback every day, one exam on Friday

- No marks from Monday to Thursday. Every demo gets one thing that convinces and one thing to challenge.
- A daily card at 17:30: one thing you would do differently on a real site.
- Friday: the FDE Certification exam. 240 questions, 120 minutes, 75% to pass, closed book.
- What prepares you for the exam is the labs, not the slides.

---
<!-- 11 | Divider | ghost: YOU -->
## Round table: who is in the room

---
<!-- 12 | Detail -->
## Every engagement starts with people, so this week does too

- On site, the first hour is introductions: who decides, who knows, who will use the system.
- The fastest way to earn access is to say plainly who you are and why you are there.
- This morning you practice it on each other: seventy-five seconds, no slides.
- You will work with these nineteen people all week, and some of them for years.

---
<!-- 13 | Framework -->
## Seventy-five seconds each, four questions, in team order

1. **Who you are.** Name, company, current role, in one sentence.
2. **Where you come from.** Engineering, consulting, data, operations, or something else.
3. **A plant you know.** One factory, warehouse or operation you have seen from the inside, and one thing that surprised you there.
4. **What you want.** The one thing you want to be able to do on Friday that you cannot do today.

---
<!-- 14 | Detail -->
## The trainer goes first

- Renan Devillières, OSS Ventures.
- Background: industrial operations and venture building; twenty-two companies co-founded with founders who sell to plants.
- A plant I know: the first time I watched a planner override an ERP schedule, she was right and the system was wrong.
- What I want on Friday: twenty people who can walk into a plant on Monday and be useful by Wednesday.

---
<!-- 15 | Detail -->
## Team 1

| Name | Company and role | Background | What I want on Friday |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---
<!-- 16 | Detail -->
## Team 2

| Name | Company and role | Background | What I want on Friday |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---
<!-- 17 | Detail -->
## Team 3

| Name | Company and role | Background | What I want on Friday |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---
<!-- 18 | Detail -->
## Team 4

| Name | Company and role | Background | What I want on Friday |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---
<!-- 19 | Detail -->
## Team 5

| Name | Company and role | Background | What I want on Friday |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---
<!-- 20 | Exercise -->
## Place yourself on the four capabilities, honestly, with four dots

1. Four posters on the wall: business judgment, field craft, engineering, meaning.
2. On each, put a dot from 1 (new to me) to 5 (I could teach it).
3. Two minutes, in silence, while the trainer reads the room.

We will look at the same posters on Friday afternoon.

---
<!-- 21 | Detail -->
## What the room already knows, and what the week must teach

<!-- complete live from the posters and the round table -->
- Strongest capability in the room:
- Weakest capability in the room:
- Plants and sectors we have seen from the inside:
- The expectation we heard most often:

---
<!-- 22 | Detail -->
## Your team's first decision: who holds which role today

- The Builder is the person most at ease in a terminal today. Tomorrow it rotates.
- The Verifier is the person most likely to say "show me".
- The Lead keeps the time and asks the trainer the questions.
- The Storyteller writes the one sentence for Hervé at 11:40.

Write the four names on your team card. Two minutes.

---
<!-- 23 | Divider | ghost: 30:00 -->
## Setup sprint: thirty minutes, then everyone can build, check and ship

---
<!-- 24 | Detail -->
## An FDE's laptop is their workshop, and on site you will not get to choose it

- On a client site you may get a locked laptop, a proxy and no admin rights.
- The habit that saves you: know exactly what your toolchain needs, and how to check it in one minute.
- This week we use the same stack everywhere, so problems are shared and fixed once.
- Thirty minutes now saves thirty hours over the week.

---
<!-- 25 | Detail -->
## The toolchain you will use all week, and what each piece is for

| Tool | What it does | First used |
|---|---|---|
| Git and GitHub | Versions every change; your team shares one repository | This morning |
| Node.js | Runs the apps and the tooling | This morning |
| Claude Code | An AI agent in your terminal that reads, edits and runs code with you | This morning |
| Vercel | Puts your app on a public URL in one command | This morning |
| Python and pandas | Lets the Verifier compute numbers independently | This morning |
| VS Code | Reads code and diffs | All week |

---
<!-- 26 | Detail -->
## Install six tools

- Node.js LTS (22 or later) and Git
- VS Code, or the editor you already use
- Claude Code, with the native installer
- Vercel CLI
- Python 3.11 or later, with pandas
- GitHub CLI (optional, makes login easier)

Installers for macOS and Windows are on the two USB keys if the Wi-Fi struggles.

---
<!-- 27 | Detail -->
## Open three accounts, all personal and free, and bookmark the program site

- **GitHub.** Your own account; you will be invited to the cohort organization.
- **Vercel.** Personal Hobby plan, linked to your GitHub account.
- **Claude.** Access is handed out now by the organizers. Never paste client data into a personal AI account.
- **The program site.** `https://fde-certification.vercel.app/`, password `fdecompany`. The program and Friday's exam live there.

---
<!-- 28 | Detail -->
## macOS, Linux or WSL: copy these commands in order

```bash
# Claude Code, native installer
curl -fsSL https://claude.ai/install.sh | bash

# Vercel CLI
npm install -g vercel

# Python libraries for the Verifier
python3 -m pip install pandas

# Check everything
node -v && git --version && python3 --version && claude --version && vercel --version
```

---
<!-- 29 | Detail -->
## Windows: PowerShell, or WSL if your laptop allows it

```powershell
# Claude Code, native installer
irm https://claude.ai/install.ps1 | iex
# If the policy blocks scripts
winget install Anthropic.ClaudeCode

# Vercel CLI and pandas
npm install -g vercel
py -m pip install pandas

# Check everything
node -v; git --version; py --version; claude --version; vercel --version
```

Raise a hand after five minutes stuck. Official setup guide: code.claude.com/docs/en/setup

---
<!-- 30 | Detail -->
## Tell Git who you are, and log in once to each service

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

gh auth login        # GitHub, browser login
vercel login         # Vercel, email method
claude               # Claude Code, first run opens the login
```

---
<!-- 31 | Framework -->
## Git in six commands is enough for this week

| Command | What it does |
|---|---|
| `git clone <url>` | Copies the team repository to your laptop |
| `git switch -c <branch>` | Starts your own line of work |
| `git status` and `git diff` | Shows what changed before you commit |
| `git add -A` and `git commit -m "..."` | Saves a change with a message that says why |
| `git pull` | Brings your teammates' changes |
| `git push` | Shares your work on GitHub |

---
<!-- 32 | Framework -->
## Claude Code is an agent in your terminal: it reads, plans, edits and runs, and asks before it acts

1. **Reads.** The files in your repository, starting with `CLAUDE.md`.
2. **Plans.** Proposes the steps before touching anything, when you ask it to.
3. **Edits.** Changes files and shows you the diff.
4. **Runs.** Executes commands and tests, and reads the output.
5. **Asks.** For permission before editing or running, unless you allowed it.

---
<!-- 33 | Detail -->
## Keep control: review every diff, approve every command, never approve what you cannot read

- Start with plan mode for anything larger than a small fix: read the plan, then let it build.
- Approve commands one by one at first. Allow a command permanently only once you trust it.
- Never approve a command that deletes, pushes or deploys without reading it.
- If the session drifts, stop it, restate the goal and start a fresh session.

---
<!-- 34 | Detail -->
## CLAUDE.md is the briefing you would give a new colleague

- **Context.** Who the client is, what the plant does, what the app is for.
- **Data.** Where the files are, what the columns mean, which units.
- **Rules.** Profile before computing; never invent a number; ask when unsure.
- **Definitions.** How OEE is computed, from sums, not averages of ratios.
- **Done.** The tests to run and the checks to pass before saying a task is finished.

The Polymex repository ships with one. Read it before your first prompt.

---
<!-- 35 | Framework -->
## A good prompt is a small spec: goal, constraints, check

| Part | Example |
|---|---|
| Goal | Add a page that shows plant OEE per week for January to March |
| Constraints | Use the definitions in `CLAUDE.md`; sum minutes and tonnes before dividing; no new libraries |
| Check | Print the plant OEE for the quarter in the terminal so I can compare it with my Verifier's |

"Build me a dashboard" is not a prompt. It is a wish.

---
<!-- 36 | Detail -->
## Secrets stay out of Git from minute one

- Keys live in a `.env` file on your laptop and in Vercel's environment variables, nowhere else.
- `.env` is in `.gitignore` before your first commit. Check it now.
- A key pushed once is a key leaked, even if you delete it in the next commit.
- If you leak one, say so immediately. Rotating a key takes two minutes; hiding it ends careers.

---
<!-- 37 | Detail -->
## Deploy with Vercel in three commands

```bash
cd polymex-plant-pulse
vercel            # first time: link the project, accept the defaults
vercel --prod     # publish to the production URL
```

Post the URL in the cohort channel. A URL anyone can open is the only demo that counts.

---
<!-- 38 | Detail -->
## If your laptop cannot install anything, work in the browser

- Open the repository on GitHub, then Code, then Codespaces, then create one.
- You get a full Linux machine in the browser, with Node.js and Git ready.
- Install Claude Code inside it with the native installer, and deploy from there with `vercel`.
- A client's locked laptop is a normal situation. This is how you work around it without breaking a rule.

---
<!-- 39 | Detail -->
## The eight problems we see every time, and their fixes

| Symptom | Fix |
|---|---|
| `claude: command not found` | Open a new terminal; the path changes for new sessions only |
| Downloads blocked | Set `HTTPS_PROXY` to the proxy, or use the guest Wi-Fi |
| PowerShell script blocked | `winget install Anthropic.ClaudeCode`, or WSL |
| No Node.js | Install the LTS from nodejs.org or the USB key |
| `git push` asks for a password | `gh auth login`, or a personal access token |
| Vercel login loops | `vercel login` with the email method |
| No admin rights | Codespaces in the browser |
| No Python | The Verifier uses a spreadsheet for today's lab |

---
<!-- 40 | Framework -->
## Work with Claude Code in a loop: plan, build, test, read the diff, commit

1. **Plan.** Ask for the steps; correct them.
2. **Build.** One step at a time.
3. **Test.** Run it; compare one number by hand.
4. **Read the diff.** Every line you will show someone.
5. **Commit.** With a message that says why.

---
<!-- 41 | Detail -->
## Five ways teams lose an hour with an AI coding tool

1. Asking for everything at once, then debugging a thousand lines nobody read.
2. Accepting a number the tool computed without checking it against the raw rows.
3. Letting the tool change the definition of a metric to make a test pass.
4. Working for an hour without committing, then losing it.
5. Arguing with a drifting session instead of starting a fresh one.

---
<!-- 42 | Exercise -->
## Done at 10:05 means six things work on your laptop

1. `claude` answers in your terminal.
2. You cloned `polymex-plant-pulse` from the cohort's GitHub organization.
3. `.env` is in `.gitignore`, and you pushed one commit to your own GitHub.
4. You deployed a hello page with `vercel` and posted the URL in the cohort channel.
5. Your Verifier can open the shift log in Python or a spreadsheet.
6. You opened `https://fde-certification.vercel.app/` with the password `fdecompany`.

Hands up at 10:05: who has all six?

---
<!-- 43 | Divider | ghost: WHY -->
## Why this job exists

---
<!-- 44 | Data -->
## People feel AI in their working day; companies do not yet see it in their P&L

| Share of respondents | |
|---|---|
| AI improved my own productivity | 80% |
| My company sees some EBIT impact from AI | 37% |
| My company attributes 5% or more of EBIT to AI | 6% |

The EBIT figure has not moved in a year, while the models kept improving.

Source: McKinsey & Company, The state of AI in 2026, August 2026 (1,719 respondents, May to June 2026).
<!-- the 6% bar in flame -->

---
<!-- 45 | Data -->
## Most enterprise pilots never reach the P&L, and the cause is rarely the model

- About 95% of enterprise generative AI pilots showed no measurable P&L impact.
- Projects run with specialized partners succeeded about twice as often as internal builds.
- The study traces the gap to how tools are integrated into work and whether they adapt, not to model quality.

Source: MIT NANDA, The GenAI Divide: State of AI in Business 2025, July 2025. Failure is defined as no measurable benefit within six months.
<!-- single large "95%" left -->

---
<!-- 46 | Data -->
## Capability has become a commodity you rent

- The cost of GPT-3.5-level output fell more than 280-fold between November 2022 and October 2024.
- The top models from six labs sit within about 25 rating points of each other on the most watched public leaderboard.
- Your competitor rents the same intelligence. The difference is what you feed it and where you put it to work.

Source: Stanford HAI, AI Index 2025 (inference cost) and AI Index 2026 (leaderboard, March 2026).
<!-- single large "×280" left -->

---
<!-- 47 | Data -->
## Agents now carry whole tasks, and the length of those tasks keeps doubling

- The length of software tasks AI agents complete on their own has doubled roughly every seven months since 2019.
- On a plant, under supervision: read an order, check capacity, propose a slot, flag the risk, draft the supplier email.

Source: METR, Measuring AI Ability to Complete Long Tasks, March 2025; Time Horizon 1.1, January 2026.
<!-- single large "7 months" left -->

---
<!-- 48 | Detail -->
## We have seen this gap before: electricity paid off only when factories were redesigned around it

- Electric motors arrived in factories in the 1880s; the productivity surge came in the 1920s.
- The gain did not come from swapping the steam engine for a big motor, but from redesigning the plant around many small ones.
- The same holds now: the gain comes from redesigning the work around the model, one workflow at a time.
- That redesign, inside a client's operation, is the FDE's job.

Source: Paul A. David, The Dynamo and the Computer, American Economic Review, 1990.

---
<!-- 49 | Framework -->
## Industrial AI fails in the last mile: data, workflow and people

| Layer | What goes wrong |
|---|---|
| Model | Rarely the problem anymore |
| Data | Lives in legacy systems, spreadsheets and heads; worse than anyone expected |
| Workflow | The tool is live, but decisions still run on habit |
| People | Operators override what they do not trust, and they are often right |

The FDE is the person who closes the last three rows.

---
<!-- 50 | Data -->
## About 40% of the data an agent needs is in no system at all

- Across more than 100 agentic deployments, OSS Ventures found that about 40% of the data agents need lives in people's heads and in spreadsheets.
- No integration project will fetch it. Someone has to go and get it, on site, from the people who hold it.

Source: OSS Ventures, analysis of more than 100 agentic deployments, 2026.
<!-- single large "40%" left -->

---
<!-- 51 | Framework -->
## Value sits where decisions need deep context and errors are expensive

| The decision needs | Errors are cheap | Errors are expensive |
|---|---|---|
| Little context | Buy off the shelf: copilots, drafting, search | Automate with guardrails: document checks, invoice matching |
| Deep knowledge of the operation | Assist a person: quote preparation, root-cause hypotheses | Build on the plant's ontology: scheduling, formulation, quality release |

Most pilots sit top left. Most of the money sits bottom right, and that is where FDEs work.

Source: OSS Ventures, brief for industrial CEOs, 2026.

---
<!-- 52 | Detail -->
## A stalled pilot is not free: it costs licences, attention and the next project

- The licence is paid whether or not anyone uses the tool.
- The plant team gave interviews, data and meetings, and got nothing back.
- The sponsor spent credibility with the board.
- The next AI proposal starts with "we tried that already".

---
<!-- 53 | Hero -->
## The bottleneck has moved from models to people who can deploy them.

---
<!-- 54 | Data -->
## The market has noticed: FDE job postings grew about eightfold in 2025

- Postings for Forward Deployed Engineers grew about 800% between January and September 2025.
- Palantir, OpenAI and Anthropic all run forward deployed teams.
- In European industry, the profile barely exists yet. You are the first cohort.

Source: Indeed data reported by the Financial Times, 2025.
<!-- single large "×8" left -->

---
<!-- 55 | Framework -->
## The role was invented to get complex software live where classic IT projects stalled

1. **Late 2000s.** Palantir puts engineers inside client organizations to make its platform work on their data.
2. **2020s.** The leading AI labs build forward deployed teams to turn models into production systems.
3. **2025.** OSS Ventures embeds engineers in industrial groups through its Transformer program.
4. **2026.** The FDE School and The FDE Company industrialize the role for European industry.

---
<!-- 56 | Detail -->
## In industry the job is harder: continuous shifts, old systems, safety and thin margins

- A plant runs day and night; a bad schedule costs tonnes by the next shift.
- Systems are decades old; the rules that matter sit in spreadsheets and notebooks.
- Safety comes first and slows everything you do on the floor.
- Margins are thin: a plant at 6.6% EBIT cannot afford a pilot that changes nothing.

---
<!-- 57 | Detail -->
## European industry needs it now: experts are retiring, and the rules leave with them

- The planners and operators who know the plant's real rules are often in the last decade of their careers.
- Their rules are rarely written down; when they leave, the plant relearns them through scrap and late orders.
- Capturing those rules in a system the next generation can use is one of the highest-value things an FDE does.
- You will meet one such expert on Thursday.

---
<!-- 58 | Data -->
## Across 3,800 sites, the difference between a pilot and a rollout was a person doing this job

- Software from OSS Ventures' 22 companies runs in about 3,800 industrial sites, with about 200,000 monthly users.
- In every rollout that worked, someone played the FDE role, whether or not it carried the name.
- In the ones that stalled, nobody did.

Source: OSS Ventures portfolio tracker, April 2026.
<!-- single large "3,800" left -->

---
<!-- 59 | Detail -->
## The client buys an outcome, not hours

- Classic IT services sell time and deliverables; the client carries the risk that nothing changes.
- An FDE engagement sells a result in production, measured in the client's own numbers.
- So the FDE's day is organized around the result, not around the statement of work.
- Expansion follows delivered value: the next site, the next problem.

---
<!-- 60 | Detail -->
## Why Devoteam and OSS Ventures are building this together

- Devoteam brings delivery at scale and the client relationships across European industry.
- OSS Ventures brings industrial software, field lessons from thousands of sites and the Transformer method.
- The FDE Company is the joint vehicle: engineers who make industrial AI software deliver what it promises.
- You are its first cohort.

---
<!-- 61 | Divider | ghost: FDE -->
## The FDE job definition

---
<!-- 62 | Detail -->
## An FDE embeds with the client, ships the system and stays accountable for the result in production

> A software engineer who embeds inside a client organization to scope, build and operate the systems that make a product deliver measurable value, and who stays accountable for the outcome in production.

The FDE Company's mission: make industrial AI software deliver the value it promises, measured in euros on the client's P&L.

---
<!-- 63 | Framework -->
## Three words carry the definition: embeds, operates, accountable

- **Embeds.** On site, inside the client's team, with access to the floor and the data.
- **Operates.** Not a prototype: a system that runs every shift and is maintained.
- **Accountable.** For the result in the client's numbers, until the routine holds without you.

---
<!-- 64 | Detail -->
## The job description, as you would read it in an offer

| Section | Content |
|---|---|
| Title | Forward Deployed Engineer, industrial AI |
| Reports to | A lead FDE on the engagement; an engineering manager at The FDE Company |
| Location | On the client's site most of the week; remote the rest |
| Mission | Turn an industrial AI product into a measured gain at one client site, then the next |
| Engagements | One to two at a time, three to twelve months each |

---
<!-- 65 | Detail -->
## Responsibilities: from the first interview to the gain in the controller's spreadsheet

1. Embed with the plant team; map the process, the systems and the people.
2. Find and size the problem worth solving, with the sponsor and the controller.
3. Capture the data and the experts' rules, and turn them into a model of the plant.
4. Build, integrate and deploy the system on the client's real data and workflows.
5. Drive adoption until decisions run on the system without you.
6. Prove the gain with the client's finance team, and feed field patterns back to the product.

---
<!-- 66 | Framework -->
## What you are measured on

| Measure | What it means |
|---|---|
| Gain signed by finance | Euros a year, computed by the client's controller from a protocol agreed in week one |
| Time to first value | Weeks from arrival to a decision taken with the system |
| Adoption | Named users who rely on the system every week |
| Expansion | The next problem or the next site, decided by the client |
| Product feedback | Field patterns turned into product changes |

---
<!-- 67 | Detail -->
## What you are not measured on

- Hours billed.
- Lines of code, features shipped or tickets closed.
- Slides produced or workshops run.
- How impressive the demo was.

None of these appears in the client's P&L.

---
<!-- 68 | Detail -->
## The FDE is not a consultant, a solutions engineer or a staffing resource

| | FDE | Consultant | Solutions engineer | Staffing |
|---|---|---|---|---|
| Output | Running systems, measured euro gains | Recommendations | Demos, proofs of concept | Hours |
| Engagement | From signature to value in production | One phase | Before the sale | The contract |
| Accountability | Same person from scoping to steady state | Until the report | Until the deal | For the task |
| Link to product | Feeds field patterns back to the product | None | Sales feedback | None |
| Commercial | Expansion follows delivered value; no quota | Sells the next phase | Carries a number | None |

---
<!-- 69 | Detail -->
## The FDE is not a product engineer either, and the difference is where you sit

| | FDE | Product engineer |
|---|---|---|
| Sits | With the client, on site | With the product team |
| Optimizes | One client's result | The product for every client |
| Code | Configuration, integration, client-specific logic | The core product |
| When the product falls short | Works around it safely, and escalates the gap | Fixes it for everyone |

---
<!-- 70 | Framework -->
## Four capabilities make an FDE, and this week trains each of them

| Capability | What it means on site | Trained on |
|---|---|---|
| Business judgment | Reads the P&L, sizes a problem in euros, knows when to say no | Day 2 |
| Field craft | Interviews, stakeholders, sponsors, change | Days 1 and 4 |
| Engineering | Builds, integrates, ships and runs software in production | Days 3 and 4 |
| Meaning | Turns data and expert rules into a model of the plant | Days 3 and 4 |

All four point at one thing: being accountable for the result.

---
<!-- 71 | Detail -->
## The career path: shadow, own a workstream, lead a deployment, lead an account

| Step | You are trusted to |
|---|---|
| Shadow | Work on a live deployment under a senior FDE; own one artifact |
| Workstream owner | Own a pipeline, a rules file or a validation protocol end to end |
| Deployment lead | Run one site: the sponsor, the plan, the gain |
| Account lead | Several sites of one group; the next problem and the next site |

---
<!-- 72 | Detail -->
## Every week, an FDE answers three questions

1. What moves this client's P&L, and by how much?
2. What really happens on the floor, as opposed to what the systems say?
3. What can I ship by Friday that someone will use on Monday?

---
<!-- 73 | Detail -->
## A week in the life: the shop floor in the morning, the director's P&L in the afternoon

| Day | Morning | Afternoon |
|---|---|---|
| Monday | Weekly operations review with the plant team | Replay last week's schedule with the planner, order by order |
| Tuesday | Two hours with the night shift | Data archaeology in the MES export |
| Wednesday | Ship a fix to the sequencing rules | Demo to the planner, who corrects two rules |
| Thursday | IT: move from file extracts to a read API | Prepare the steering committee |
| Friday | Steering committee: gains against the baseline the controller agreed | Plan next week |

---
<!-- 74 | Detail -->
## A day on site, hour by hour

| Time | What you do |
|---|---|
| 6:45 | Shift handover on the floor: listen, do not speak |
| 8:30 | Daily production meeting: note every number questioned |
| 9:30 | Build: the fix promised yesterday |
| 12:00 | Lunch in the canteen with the shift leaders |
| 14:00 | Session with the planner: two rules to validate |
| 16:00 | Deploy, then a note to the sponsor: what changed, what is next |
| 17:00 | Verification log, tomorrow's plan |

---
<!-- 75 | Framework -->
## The FDE loop: embed, find, build, deploy, drive adoption, expand

1. **Embed** with the client team, on site.
2. **Find** the problem worth solving, in euros.
3. **Build** fast with what exists.
4. **Deploy** into real workflows, not a sandbox.
5. **Drive adoption** until the new routine holds without you.
6. **Expand** to the next problem or the next site.

---
<!-- 76 | Detail -->
## Each turn of the loop leaves an artifact the client keeps

| Phase | Artifact |
|---|---|
| Embed | Stakeholder map, systems map, process walk notes |
| Find | Problem statement, sized opportunity, signed charter |
| Build | Working system, rules file, eval set |
| Deploy | Runbook, data contract, IT handover |
| Drive adoption | Usage log, validation report signed by finance |
| Expand | Replication plan for the next site |

---
<!-- 77 | Detail -->
## You work with two teams at once: the client's and your own

| Client side | Your side |
|---|---|
| Sponsor: decides and funds | Lead FDE: plan and quality |
| Users: planners, operators, shift leaders | Product team: the core software |
| Expert: the person who knows the real rules | Account lead: the relationship and the next site |
| IT: access and security | Fellow FDEs: patterns from other sites |
| Finance: the baseline and the gain | |

---
<!-- 78 | Detail -->
## You are the product's eyes in the field

- Every workaround you build is a signal that the product falls short.
- Write the pattern down: what the client needed, what you did, how often you have seen it.
- Escalate; do not fork. A private version for one client becomes a debt nobody can pay.
- The best product decisions at OSS companies started as an FDE's field note.

---
<!-- 79 | Detail -->
## The first three months are discovery and stabilization, so plan them that way

- Data quality problems appear only when AI first runs on real data.
- Organizational change moves slower than technical plans.
- A three-month delay on a first engagement taught the lesson: budget discovery up front and the "delay" disappears.

Source: OSS Ventures, Transformer review after six months, April 2026.

---
<!-- 80 | Data -->
## Expect about 30% of initiatives to fail, and stop them early

- Agentic software is harder to deploy than classic SaaS, not easier.
- Impressive demos are a graveyard: a demo on clean data proves nothing about production.
- The gains worth changing a plant for are multiples, around 10x, not 10%.

Source: OSS Ventures, contrarian learnings, March 2026, and Transformer review, April 2026.
<!-- single large "30%" left -->

---
<!-- 81 | Detail -->
## Five things an FDE never does

1. Hide a slip from the sponsor.
2. Claim a gain finance has not signed.
3. Fork the product for one client instead of escalating the gap.
4. Collect data in a way that reads as monitoring people.
5. Leave before the new routine holds without them.

---
<!-- 82 | Detail -->
## Safety and people come before the system

- On the floor, the site's safety rules win over your schedule, every time.
- Your software never writes to a machine without a human and the site's approval.
- Data about operators is personal data; in France the works council is consulted before any tool that could monitor people.
- If a gain depends on someone losing their job, say so to the sponsor; never hide it in a model.

---
<!-- 83 | Framework -->
## The path from here: train, shadow a live deployment, then lead

1. **This week.** The FDE School.
2. **The next two to four months.** Shadow a senior FDE on a live, billed deployment.
3. **Then.** Lead a workstream, then a deployment.

Source: FDE School format agreed by Devoteam and OSS Ventures, July 2026.

---
<!-- 84 | Exercise -->
## Write the definition in your own words, then test it on your neighbor

1. Two sentences: what an FDE is accountable for, and what it is not.
2. Read it to the person on your left. They answer one question: would a plant director hire this person?
3. Swap. Three minutes in total.

---
<!-- 85 | Divider | ghost: PLANT -->
## The context of the role: how a plant is run

---
<!-- 86 | Framework -->
## A plant is a small company with its own chain of command

| Function | Owns |
|---|---|
| Site director | The plant's P&L, safety and people, with HSE |
| Production | Output, shifts, crews |
| Planning and supply chain | What runs where and when; materials in, goods out, stock |
| Maintenance | Machine availability, spare parts |
| Quality | Product release, customer complaints |
| Controller | The numbers finance believes |
| IT and OT | Systems, networks, access |

---
<!-- 87 | Detail -->
## Know who decides what before you propose anything

| Decision | Usually decided by |
|---|---|
| Next week's schedule | Planning, with production |
| A change to a machine setting | Production and maintenance, with quality |
| Access to a system | IT, often the group's IT |
| A new tool on the floor | Site director, with production; works council if it touches people |
| What counts as a gain | The controller |
| Budget for the next phase | Site director or the group, depending on the amount |

---
<!-- 88 | Framework -->
## The plant runs on five rhythms, and each is a place to be seen

1. **Shift.** Eight hours, with a handover at the start.
2. **Day.** The morning production meeting: yesterday's numbers, today's problems.
3. **Week.** The schedule frozen on Friday, the operations review on Monday.
4. **Month.** The close: finance's numbers, the KPI review with the group.
5. **Year.** The budget, where next year's projects are funded.

---
<!-- 89 | Detail -->
## The morning production meeting is where the plant thinks out loud

- Fifteen minutes, standing, in front of a board: safety, quality, output, delivery, people.
- Every number on the board is contested by someone. Write down which ones.
- Problems are named here before they reach any system.
- Attend every day in your first two weeks. Speak only when asked.

---
<!-- 90 | Framework -->
## A plant makes money through throughput at its bottleneck, times margin

- Output is set by the slowest stage: the bottleneck.
- An hour lost at the bottleneck is lost for the whole plant; an hour saved anywhere else is a mirage.
- Contribution margin, not full cost, says what one more tonne is worth.

Tomorrow morning, we read a plant P&L and price these effects.

---
<!-- 91 | Framework -->
## Process and discrete plants fail differently

| | Process (Polymex) | Discrete |
|---|---|---|
| Makes | Tonnes or litres: compounds, chemicals, food | Units: parts, machines, assemblies |
| Changeovers | Purges and cleaning, sequence-dependent | Tooling and setups |
| Quality | Lab results on batches | Inspection of parts |
| Typical leak | Changeover sequence, scrap, energy | Setups, rework, missing parts |

---
<!-- 92 | Framework -->
## Six numbers every plant lives by

| KPI | Question it answers |
|---|---|
| OEE | How much of planned time produced good output? |
| OTIF | Did we deliver on time and in full? |
| Scrap rate | How much material did we throw away? |
| Changeover time | How much time did switching products cost? |
| Inventory days | How much cash sits in stock? |
| Safety incidents | Did anyone get hurt? Always first on the board |

---
<!-- 93 | Framework -->
## You will meet the same families of systems in every plant

| System | Holds |
|---|---|
| ERP | Orders, stock, purchasing, finance: the system of record |
| MES | What happens on the shop floor, shift by shift |
| APS | Planning and scheduling |
| WMS | The warehouse |
| PLM | Product and recipe data |
| QMS and CMMS | Quality, and maintenance |
| SCADA and historians | Machine signals |

Keep the ERP as system of record; add a thin layer that reads from it. Day 3 goes deep.

---
<!-- 94 | Framework -->
## The model is rented; the ontology is yours

- The ontology is a formal model of what exists in the plant, how things relate, which rules apply and which actions are allowed.
- Most projects model the facts and skip the rules experts use to judge a good decision. The rules carry the value.
- Grounding a model in a knowledge graph roughly tripled answer accuracy in data.world's benchmark, from 16% to 54%.

Source: Sequeda, Allemang and Jacob, data.world, 2023 (arXiv 2311.07509). Day 3 goes deep.

---
<!-- 95 | Detail -->
## The group buys, the site uses, and you must win both

- The group sees a portfolio of sites and a budget line; it wants a pattern it can replicate.
- The site sees one more project on a full plate; it wants its problem solved this month.
- A deployment that pleases the group and burdens the site dies at the site.
- A deployment that pleases the site and cannot be replicated dies at the group.

---
<!-- 96 | Detail -->
## What the floor fears from new software, and is often right to

- **Surveillance.** A tool that measures machines can be used to judge people.
- **Replacement.** "The system will do the planner's job."
- **Extra work.** One more screen, one more field to fill, one more meeting.
- **Being wrong in public.** The tool contradicts years of experience in front of the boss.

Thursday afternoon goes deep, with the people of Polymex.

---
<!-- 97 | Framework -->
## A gain exists only when the client's finance team signs it

- Software frees capacity; only a decision turns it into money: fill the hours, or stop the overtime.
- Agree the baseline with the controller in week one, before any code runs.
- The gain is then announced by their spreadsheet, not yours.

Tomorrow afternoon, you write a validation protocol a controller could run without you.

---
<!-- 98 | Detail -->
## Five site rules you follow from your first visit

1. Wear the protective equipment the site requires, every time, including for a five-minute walk.
2. Follow your escort; never cross a marked zone alone.
3. Never touch a machine, a panel or a setting.
4. Ask before taking a photo. Some lines and products are confidential.
5. If an alarm sounds, follow the crew, not your laptop.

---
<!-- 99 | Detail -->
## Your first week on a new site, in order

1. Day 1: the safety induction, the sponsor, a walk of the whole flow with someone who runs it.
2. Day 2: a full shift on the floor, including the handover.
3. Day 3: the planner, maintenance, quality and the controller, one hour each.
4. Day 4: read access to the first data export, and a first profile of it.
5. Day 5: a one-page note to the sponsor: what I saw, what I think, what I will check next.

---
<!-- 100 | Hero -->
## You are paid for the decisions your work makes possible, not for the code.

---
<!-- 101 | Divider | ghost: LAB -->
## Lab: Polymex Plant Pulse

---
<!-- 102 | Detail -->
## Meet Polymex Industries, the plant you will work in all week

- Plastics compounding: 86,000 tonnes a year, €148M revenue, €9.7M EBIT.
- A mixing hall, seven extrusion lines (M01 to M07), a packing hall. Three shifts, seven days a week.
- Since January, two retail clients order small, frequent batches. On-time-in-full delivery is slipping.
- Hervé, the site director, wants to see the plant on one page by Friday.

---
<!-- 103 | Framework -->
## Material flows through three stages, and one of them sets the pace

1. **Mixing.** Resins, additives and pigments are weighed and blended into batches.
2. **Extrusion.** Seven lines melt, compound and pelletize the batches.
3. **Packing.** Pellets are bagged, palletized and shipped.

Which stage is the constraint? Your data will tell you.

---
<!-- 104 | Detail -->
## The people you will meet this week

| Person | Role |
|---|---|
| Hervé | Site director, your sponsor |
| Corinne | Planner, eleven years at Polymex |
| Marc | Extrusion operator on M04, twenty-three years |
| Nadia | IT manager |
| Mireille | Group CFO, with her plant controller |

Today you only need Hervé. The others arrive during the week.

---
<!-- 105 | Detail -->
## The data you get: two files and a dictionary

| File | Content |
|---|---|
| `data/extrusion_shift_log.csv` | One row per machine and shift, January to March 2026: planned, changeover, downtime and run minutes; output and scrap; ideal rate |
| `data/stage_daily.csv` | One row per stage and day: minutes starved and blocked |
| `data/DATA_DICTIONARY.md` | What every column means, and in which unit |

Ninety days, seven lines, three shifts. Read the dictionary before the first prompt.

---
<!-- 106 | Framework -->
## OEE multiplies three ratios, each computed from sums

| Ratio | Formula |
|---|---|
| Availability | Run minutes ÷ planned minutes |
| Performance | Output ÷ (run hours × ideal rate) |
| Quality | (Output − scrap) ÷ output |
| OEE | Availability × performance × quality |

Sum minutes and tonnes over the period first, then divide. Never average per-row ratios.

---
<!-- 107 | Detail -->
## The constraint is the stage that is always busy and never waits

- Upstream of the constraint, stages are blocked: they cannot hand over their work.
- Downstream, stages are starved: they wait for work.
- The constraint itself is neither starved nor blocked for long.
- `stage_daily.csv` gives you the minutes. Show the evidence, not only the answer.

---
<!-- 108 | Exercise -->
## Your brief: a one-page app, deployed, with numbers another pair has checked

Build in 35 minutes, demo in 2:

1. Good output per day, and its trend.
2. Extrusion OEE for the plant and per machine: availability × performance × quality.
3. The constraint, with evidence.
4. Changeovers per week.
5. One insight Hervé does not know, as a sentence with a number.
6. Data notes: every anomaly, and what you did about it.

Repository: `polymex-plant-pulse` in the cohort's GitHub organization.

---
<!-- 109 | Framework -->
## Two pairs, one truth: Pair A builds, Pair B checks

| Pair A | Pair B |
|---|---|
| Builds the app with Claude Code from the repository | Never looks at Pair A's code |
| `CLAUDE.md` gives the context and the working rules | Computes three numbers independently: plant extrusion OEE, M07 OEE, changeovers in the week of 23 March |
| Writes `DATA_NOTES.md` | Fills in `VERIFY.md` |

Demo only when both pairs agree, or when you can explain the difference.

---
<!-- 110 | Detail -->
## What is already in the repository

| File | Use it for |
|---|---|
| `README.md` | The brief and the definition of done |
| `CLAUDE.md` | The context and rules Claude Code reads first |
| `VERIFY.md` | Pair B's log: number, method, value, match |
| `data/` | The two files and the dictionary |
| `.gitignore` | Already excludes `.env`; keep it that way |

---
<!-- 111 | Detail -->
## A first prompt that works

```text
Read CLAUDE.md, README.md and data/DATA_DICTIONARY.md.
Before writing any app code, profile data/extrusion_shift_log.csv:
row counts per date and shift, ranges of every numeric column,
duplicates, missing dates or shifts, and anything that looks like a unit error.
Write the profile to DATA_NOTES.md and stop. Do not fix anything yet.
```

Then read the profile together, and decide what to do about each anomaly.

---
<!-- 112 | Detail -->
## Verification discipline: five habits, starting today

1. Profile the data before computing: counts, ranges, duplicates, gaps, units.
2. Check one number by hand against the raw rows.
3. Read the code that computes every number you show.
4. Hunt silent assumptions: units, shifts, planned time, averages of ratios.
5. Write down what you checked. A claim without a check is an opinion.

Speed comes from the tools. Trust comes from the method.

---
<!-- 113 | Detail -->
## Thirty-five minutes, in four stops

| Clock | Pair A | Pair B |
|---|---|---|
| 0 to 8 | Profile the data, write `DATA_NOTES.md` | Open the log; compute plant OEE by hand |
| 8 to 25 | Build the page, one metric at a time | M07 OEE, changeovers in the week of 23 March |
| 25 to 30 | Deploy with `vercel --prod` | Compare with Pair A; log in `VERIFY.md` |
| 30 to 35 | Fix what disagrees; redeploy | The Storyteller writes the sentence for Hervé |

---
<!-- 114 | Detail -->
## Done means six things, all true at 11:43

1. A public URL that opens on any phone.
2. The five metrics on one page.
3. `DATA_NOTES.md` lists every anomaly and what you did.
4. `VERIFY.md` shows Pair B's three numbers and whether they match.
5. One sentence for Hervé, with a number.
6. No key in the repository.

---
<!-- 115 | Detail -->
## Demo in two and a half minutes: the URL, the constraint, a checked number, an insight, a question

1. The URL, live.
2. The constraint, and how you know.
3. One number you verified, and how.
4. Your insight for Hervé, in one sentence with a number.
5. The first question you would ask Hervé on Monday.

---
<!-- 116 | Detail -->
## Feedback follows one rule all week

- One thing that would convince Hervé.
- One thing he would challenge.
- Nothing else. No "great job", no list of ten.

---
<!-- 117 | Detail -->
## What the demos taught us

<!-- complete live after the demos -->
- Anomalies the tool found on its own:
- Anomalies a human caught:
- Where Pair B disagreed, and who was right:
- The insight that would make Hervé act on Monday:

---
<!-- 118 | Detail -->
## Three things to keep from this morning

1. The model is a commodity. Deployment is the scarce skill, and it is the one you are here to learn.
2. An FDE is accountable for a measured result in production, not for a deliverable.
3. Every number you show must survive someone else's check.

---
<!-- 119 | Detail -->
## Go further

**Read**
- Ajay Agrawal, Joshua Gans and Avi Goldfarb, *Power and Prediction* (2022): why AI pays only when the system around it is redesigned.
- Marco Iansiti and Karim Lakhani, *Competing in the Age of AI* (2020): the operating model of AI-first companies.
- Ethan Mollick, *Co-Intelligence* (2024): working alongside AI, day to day.
- Eliyahu Goldratt, *The Goal*: the bottleneck, told as a novel. Start it tonight for Day 2.

---
<!-- 120 | Detail -->
## This afternoon: consulting skills 101

- Structure the problem: issue trees, hypotheses, the TIP one-pager.
- Structure the message: answer first, the pyramid, action titles.
- Navigate the organization: the sponsor, the users, the expert, IT, finance.
- 13:30, same room, same teams. Bring your Plant Pulse URL.
