# Day 4 afternoon: human roadblocks. Facilitator guide

*AI 50%: drafted by Claude from the FDE School curriculum and the Polymex cast, validated by the trainer.* Trainer: Renan. 13:30 to 17:30. Deck: `D4 PM - Deck - Human roadblocks.dc.html` (23 slides; content in `D4 PM - Deck content.md`). Handout: `D4 PM - Exercises.md`. Trainer only: `D4 PM - Role cards - trainer only.md`, one printed card per character per group.

## Objectives

By 17:30 every participant can:

1. Name the fear behind a stance and address it before arguing with the stance.
2. Turn an expert user into the co-author of the system.
3. Get a tacit workaround shared without making the operator feel watched.
4. Tell a sponsor his theory is wrong, in private, from his goal, with the test he agreed to.
5. Own a mistake with IT and restore trust with facts and a written report.

## What you reveal today

Both secrets held since Monday come out this afternoon:

1. **Corinne's overrides help.** The backtest (slide 13): her executed schedule delivers about 3 OTIF points more than the Friday ERP plan. Reveal it at 15:15, after rounds 1 and 2, so that round 1 is played without it.
2. **What the footprint review means for Lyon.** The review itself is public since Day 2 (board memo in the bundle). Hervé's card holds what Laurent told him: Lyon's volume could move to Haguenau's empty capacity. Let teams discover it in round 3 by asking "why now?"; reveal it in the debrief if nobody does.

## Room and casting

- Groups of four inside each team; the cards circulate face down.
- Round 3 is in plenary: you play Hervé for two teams, the other three teams observe with the sheet.
- If a real key leaked on Day 3 (Nicolas's handover), use that team in round 4 and say so kindly. If none leaked, use the card as written.

## Run sheet

| Time | Slides | Block | Notes |
|---|---|---|---|
| 13:30 | 1 to 9 | Why people resist | 30 minutes. |
| 14:00 | 10 | Round 1, Corinne | 5 prep, 10 play, 5 debrief in groups, 10 plenary. |
| 14:30 | 11 | Round 2, Marc | Same format. |
| 15:00 | | Break | Fifteen minutes. |
| 15:15 | 12 to 16 | Telling a sponsor he is wrong | 20 minutes; reveal the backtest on slide 13. |
| 15:35 | 17 | Round 3, Hervé | Two teams, ten minutes each, plenary; 15 minutes of room debrief. |
| 16:10 | 18 | Round 4, Nadia | 5 prep, 10 play, 5 debrief, 10 plenary. |
| 16:40 | 19 | Round 5, Sylvie | All groups at once: 3 prep, 10 play, 2 debrief in groups. |
| 16:55 | 20 to 21 | Debrief | 20 minutes: fill slide 21 with the room. |
| 17:15 | 22 to 23 | Close | Fifteen minutes, including the daily card and Friday logistics. |

## Slide notes

**Slide 2.** Ask the room: "Whose job did Plant Pulse change this week?" Corinne's, Marc's, the controller's, Nadia's.

**Slide 6.** Each row is a character they will meet in the next three hours. Sylvie is the one they planned the news for on Monday.

**Slide 7.** Keep Switch short; it is a lens, not a theory to recite.

**Slide 9.** Field story: the first user of a deployment was a night-shift leader. The project manager fixed his first request at 2 a.m. on WhatsApp; he defended the tool for two years.

**Slide 13.** Say it plainly: Hervé's culprit is innocent. Then the question that matters: "How do you tell him without making him lose face?"

**Slide 14.** The five moves are the grid for round 3.

## What good looks like, round by round

**Round 1, Corinne.** Strong FDEs ask her to own the rules ("I need your signature on each rule, because you are the only one who knows them"), offer her Friday evening back, and never ask her to justify an override. Best outcome: she offers her own notebook, which contains a rule the team did not have (PA6 after black PP on M06 needs 20 more minutes of purge). Weak: "We just need you to check our file."

**Round 2, Marc.** Strong FDEs start with a question about the machine, not about him; promise in writing that the data is about the line; mention the works council before he does; propose his setting as the M04 standard under his name and the screw replacement as the real fix. Best outcome: he explains −5% screw speed and +8 °C in zone 3 and agrees to show the weekend crew leader. Weak: showing the weekday-weekend chart first.

**Round 3, Hervé.** Strong FDEs pre-wire alone; start from OTIF 95% and "a site the group keeps"; ask "why now?" and get what the footprint review means for Lyon; present the backtest as the result of the branch he agreed to on Monday; hand him the better story; ask him to present it himself on Friday. Weak: "your theory is wrong", or attacking the APS.

**Round 4, Nadia.** Strong FDE leads own it in the first sentence, bring times and facts (rotated at 22:40, history cleaned, the key reached no Polymex data), commit to secret scanning and a pre-commit hook, and offer the report tonight. Weak: minimizing, or asking for access before explaining.

**Round 5, Sylvie.** This is the other side of Monday's Exercise 5: the sequence was followed, and the news still leaked through a demo. Strong FDEs listen first, acknowledge that she heard it late and that this was wrong, say clearly what they do not decide, and ask what she knows ("Which errors do you catch that SAP never shows?"). Best outcome: she mentions her correction notebook and agrees to show it on Monday; it holds six years of the errors the morning's pipeline quarantines. Weak: reassurance ("nothing will change"), deflecting to Hervé, any promise about her job. In the debrief, link it to Monday: the person whose task is automated is not the champion, and is still owed honesty and a real role in the work. Here she also turns out to hold data nobody else has.

## Debrief (16:55)

Fill slide 21 live, character by character, with quotes from the observer sheets. Then three questions: what did you see, so what, now what. End with: "On Friday, the companies are real. The characters will be too."

## Close (17:15)

Slide 22, the card, then Friday logistics: laptops charged, chargers, the exam at 14:45, the confidentiality rules for the cases (program guide).

## Trainer retro, after the day

- Which participants never played the FDE today? Give them the lead role on Friday morning.
- Talk tonight to the participants whose companies are behind Friday's cases (program guide, confidentiality protocol).
