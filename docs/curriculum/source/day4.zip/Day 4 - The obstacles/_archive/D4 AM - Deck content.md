<!-- DECK: FDE School, Day 4 morning, "Technical roadblocks". 24 slides, 9:00 to 12:00. Trainer: Renan. -->
<!-- Conventions for Claude Design: slides are separated by a line of three dashes. The first comment of each slide gives its number and type. Text inside comments is design direction, never slide text. Identity: OSS Ventures design system. Ink #0D0D0D, paper #FDFDFD, flame #FD594F as the single accent; Fjalla One uppercase titles, Inter body, Archivo labels, Geist Mono for sources and figures; brand photography only. Rendered deck: "D4 AM - Deck - Technical roadblocks.dc.html". -->

<!-- 1 | Title -->
# FDE School
## Day 4 morning: technical roadblocks

FDE School, by Devoteam and OSS Ventures
Renan Devillières

*AI 50%: drafted with Claude from the FDE School curriculum and OSS field material, validated by the trainer.*

---
<!-- 2 | Hero -->
## On Monday the data was clean because we cleaned it. In production, nobody will.

---
<!-- 3 | Detail -->
## This morning: dirty data, legacy systems, dead ends, and a pipeline that survives them

| Time | Block | You leave with |
|---|---|---|
| 9:00 | Stand-up | Yesterday's checker, one line per team |
| 9:10 | How plant data gets dirty | The seven families of dirt |
| 9:30 | Pipelines that do not lie | Raw zone, keys, idempotence, quarantine |
| 9:50 | Lab: Plant Pulse v2 | A pipeline on the April exports |
| 11:05 | Legacy and dead ends | What to do when the system says no |
| 11:20 | Exercise 2 | The naive-deployment failure memo |
| 11:40 | Demos | Feedback from the room |
| 11:55 | Close | Three things to keep |

---
<!-- 4 | Divider | ghost: DIRT -->
## Part 1. How plant data gets dirty

---
<!-- 5 | Framework -->
## Plant data gets dirty in seven predictable ways

| Family | What it looks like |
|---|---|
| Schema drift | A software update renames, reorders or drops columns |
| Units and formats | Kilograms instead of tonnes, decimal commas, dd/mm dates |
| Encoding | Accents turned into question marks, Windows-1252 read as UTF-8 |
| Duplicates and corrections | The same shift twice; a corrected file that must replace the first |
| Gaps and late arrivals | A missing day that shows up a week later |
| Impossible values | Run time longer than planned time, negative scrap |
| Silent truth gaps | Micro-stops nobody logs, workarounds nobody writes down |

---
<!-- 6 | Data -->
## Summed naively, April's exports say Polymex made almost four million tonnes

- The real April output is about 7,070 tonnes; good output 6,640.
- Every family of dirt is in the files you get this morning.
- Your v0 loader would have read most of them without an error message.

Source: Polymex LineLog exports, April 2026 (Day 4 lab kit, answer key).
<!-- one large figure "×560" left -->

---
<!-- 7 | Detail -->
## The worst errors raise no exception

- A crash is a gift: someone notices.
- A unit change multiplies a line by a thousand and the chart rescales politely.
- A corrected file read next to the original doubles one shift, and nobody looks at one shift.
- A missing day lowers the monthly average by 3% and looks like a bad day.

---
<!-- 8 | Divider | ghost: IDEM -->
## Part 2. Pipelines that do not lie

---
<!-- 9 | Framework -->
## Four layers keep the truth recoverable

1. **Raw zone.** Every file copied unchanged, with its hash. Never edited.
2. **Normalized.** One schema, one unit, one code per machine and shift.
3. **Validated.** Rows that pass the checks; the others go to quarantine with a reason.
4. **Served.** The tables the app and the controller read.

---
<!-- 10 | Detail -->
## Idempotent means you can run it again without fear

- The natural key of a row is the business key: date, shift, machine.
- Writes are upserts on the key, never appends.
- Which source wins on the same key is a written rule: the latest correction wins.
- Outputs are sorted and formatted the same way every time: run twice, compare the files byte for byte.

---
<!-- 11 | Framework -->
## Seven checks run on every load, before any number reaches a screen

- **Schema.** Expected columns, types, separator and encoding.
- **Units.** Values in the expected range for the unit.
- **Completeness.** 21 machine-shifts per day; missing days listed.
- **Uniqueness.** One row per key after corrections.
- **Validity.** Run within planned time; nothing negative.
- **Freshness.** The latest date loaded, and how old it is.
- **Reconciliation.** Monthly totals against SAP, within 2%.

---
<!-- 12 | Detail -->
## Quarantine, do not fix: a silent correction is a lie with good intentions

- A quarantined row keeps its value, its file and its reason.
- Someone with the authority to decide fixes it at the source, or writes the rule.
- The data-quality report shows the quarantine count next to every KPI.
- The controller trusts a number more when she can see what was left out.

---
<!-- 13 | Detail -->
## A data contract turns the source owner's habits into commitments

| Clause | Example for LineLog |
|---|---|
| Delivery | One file per day, by 07:00, in the shared export folder |
| Format | Declared columns and units; any change notified two weeks ahead |
| Corrections | Named with a version suffix; the latest version wins |
| Late files | Flagged after 24 hours, chased by production |
| Owner | Production for content, Nadia for the folder |

---
<!-- 14 | Divider | ghost: LAB -->
## Lab: Plant Pulse v2

---
<!-- 15 | Exercise -->
## Your brief: ingest April without a single silent error

1. Profile every file in both drops before you parse anything.
2. Build the raw zone, the normalization and the checks.
3. Make it idempotent and prove it with a test.
4. Reconcile April output per line against SAP.
5. Publish April on the Plant Pulse page, with the data-quality report.

Seventy-five minutes. Repository: `polymex-plant-pulse-v2` in the cohort's GitHub organization.

---
<!-- 16 | Detail -->
## Three runs prove idempotence

| Run | Inputs | Expected |
|---|---|---|
| 1 | Drop of 26 April only | 22 April and 26 to 30 April flagged missing |
| 2 | Then the drop of 3 May | Complete month; the 9 April correction replaces the original |
| 3 | The drop of 3 May again | Outputs byte-identical to run 2 |

---
<!-- 17 | Divider | ghost: LEGACY -->
## Part 3. Legacy systems and dead ends

---
<!-- 18 | Framework -->
## When the system has no API, climb down the ladder, not around the rules

1. **Ask the vendor.** A documented export or a read API often exists and nobody asked.
2. **Use the file it already writes.** Reports, exports, print spools.
3. **Read the database view.** Read-only, with IT, in a DMZ.
4. **Capture the missing data.** A tablet form or a sensor, where the event happens.
5. **Never.** Screen scraping on production screens, or a cable into the PLC.

---
<!-- 19 | Detail -->
## A cheap sensor beats a perfect integration for a missing signal

- M07 has no historian connection and its micro-stops are never logged.
- A current clamp on the main drive, a small gateway, one signal every second: a few hundred euros.
- Two weeks of data settle the 376-tonne question that the logs cannot.
- Agree it with maintenance and the works council before installing: it watches a machine, not a person.

---
<!-- 20 | Detail -->
## Six dead ends you will meet, and the move that usually opens them

| Dead end | Move |
|---|---|
| The vendor will not open the system | Ask what the system already exports; involve the client's purchasing |
| IT's review takes six weeks | Start it on day one; work on exports while it runs |
| The data does not exist | Capture it at the source for two weeks |
| Two systems disagree | Name the source of truth; reconcile monthly |
| The format changes without notice | A data contract with a change-notice clause |
| The expert is retiring | Record the rules with him now, validated by his successor |

---
<!-- 21 | Exercise -->
## Exercise 2: the naive-deployment failure memo

1. Imagine Plant Pulse v2 went live on 14 April with yesterday's v0 loader.
2. Write the memo you would send Hervé on 30 April: what went wrong, when, who saw it, what it cost in trust.
3. For each failure, the check or contract clause that would have caught it.
4. End with what you change before go-live.

Twenty minutes. Your Storyteller writes; the team supplies the failures from the lab.

---
<!-- 22 | Detail -->
## Demo in three minutes: the profile, the quarantine, idempotence, the reconciliation

1. What you found in the files that you did not expect.
2. Your quarantine, with reasons.
3. The idempotence test, run live.
4. April output against SAP, line by line.

---
<!-- 23 | Detail -->
## Three things to keep from this morning

1. Raw zone, business keys and upserts: run it twice without fear.
2. Quarantine with a reason; never fix silently.
3. A data contract with the source owner, and a reconciliation with finance, every month.

---
<!-- 24 | Detail -->
## Go further, and this afternoon

**Read**
- Martin Kleppmann, *Designing Data-Intensive Applications*: idempotence, exactly-once and why it is hard.
- Gene Kim and others, *The Phoenix Project*: what unplanned work does to a team.

**This afternoon**
- Human roadblocks: Corinne, Marc, Hervé and Nadia, in role-plays.
