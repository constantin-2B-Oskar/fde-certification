# Day 4 afternoon: role cards. Trainer only

*AI 50%: drafted by Claude from the FDE School curriculum and the Polymex cast, validated by the trainer.* Print one card per character. The secret part is read by the person who plays the character, never shown to the FDE side. In rounds 1, 2, 4 and 5 participants play the characters; in round 3 the trainer plays Hervé.

---

## Corinne, planner, 11 years at Polymex (Round 1)

**Public.** Corinne builds the extrusion plan every Friday from SAP and rewrites it every day. She gave the team an interview on Monday and has been asked to validate their rules file.

**Secret.**
- Last week a supplier's sales rep told her that Polymex is "looking at an APS". Since then she has heard Hervé said "a stronger planner" to the COO. She believes the FDE team is the first step of her replacement.
- Her overrides work, and she knows it. She keeps a small notebook of her own rules, more precise than what she told the team on Monday (for example: PA6 after a black PP needs an extra 20 minutes of purge on M06, because its screw is older).
- She is tired: Friday evenings until 20:00, phone calls on Saturday.

**What moves her.**
- Being asked to *own* the rules: her name in `validated_by`, her approval on every change.
- Concrete relief: "the checker gives you back your Friday evening."
- Hearing that the backtest shows her schedule beats the official plan (only if the FDE knows it; in round 1 they do not yet).

**What loses her.**
- "Explain why you override the plan": it sounds like an audit.
- Any mention of automation of the plan, or of the APS.
- Being thanked vaguely.

**If the conversation goes well,** she offers her notebook and agrees to validate the rules file by Wednesday. **If badly,** she says "everything is in the interview" and stays polite.

---

## Marc, extrusion operator on M04, 23 years (Round 2)

**Public.** Marc runs M04 on the weekday day shift. M04 performs about 15 points worse at weekends, with more scrap.

**Secret.**
- M04's screw has been worn since 2024. On weekdays Marc lowers the screw speed by about 5% and raises zone 3 by 8 °C. Surging stops and the line holds its rate. The weekend crew uses the standard setpoints.
- He suggested a change in 2024 and was told "follow the standard". He has done it quietly since.
- He is afraid a monitoring tool will show his non-standard setpoints and that he will be blamed. He also knows the works council was never consulted about the shift logger.

**What moves him.**
- Respect for his experience, asked as a question: "What do you do that the weekend crew does not?"
- A promise in writing that the data is about the machine, not about him, and that the works council will be informed.
- Making his setting the standard, under his name, and asking maintenance to quote the screw replacement.

**What loses him.**
- Showing him a chart of "his" performance against the weekend crew.
- Any word like "deviation", "non-compliance" or "monitoring".

**If it goes well,** he explains the setting and agrees to show it to the weekend crew leader on Saturday. **If badly,** "I just follow the standard."

---

## Hervé, site director (Round 3, played by the trainer)

**Public.** Hervé sponsors the project. He told the COO that Polymex needs a serious APS and probably a stronger planner. Friday is the steering committee with Mireille.

**Secret.**
- Everyone knows a footprint review goes to the board in June (it is in the Day 2 bundle). What nobody knows: in March, Laurent told Hervé privately that if Lyon's OTIF and EBIT have not turned by June, Lyon's volume could move to Haguenau's empty capacity. This is his real "why now".
- The APS and planner story was his way to show action quickly. He is not attached to it; he is attached to looking in control.
- He respects people who bring him numbers before a meeting, and he hates being surprised in front of Mireille.

**What moves him.**
- Hearing the result alone, before Friday, framed against his goal: OTIF at 95% and a site the group keeps.
- A better story he can tell the COO: "We found that retail micro-orders were eating our capacity; here is a twelve-week plan with gains Mireille's controller will validate."
- Corinne presented as an asset to formalize, not a problem to replace.

**What loses him.**
- "You were wrong", or any sentence that makes him the problem.
- New bad news without options.
- Being told the APS is useless; he will defend it. "The APS decision belongs to the group; our results will make it a better decision" works.

**If it goes well,** he asks the team to present the backtest on Friday and drops the planner line. **If badly,** "Put it in the report, I will read it", and the team has lost Friday.

---

## Nadia, IT manager (Round 4)

**Public.** Nadia granted read access to the LineLog export folder on Wednesday, on her five conditions.

**Secret.**
- Last night group security's scanner found a live API key in a public repository of the cohort's GitHub organization (if a real key leaked on Day 3, use it). She revoked the team's access to the folder at 7:00 and must file a report to group security by tomorrow.
- She is not angry at the person; she is angry that it is exactly the 2022 pattern: nobody owned the system.
- She wants to restore access. She needs a reason she can defend.

**What moves her.**
- The FDE lead owning it immediately: "It was our mistake. Here is what we have done."
- Facts: when the key was rotated, whether the repository history was cleaned, what data the key could reach (none of Polymex's), how it will not happen again (secret scanning, pre-commit hook, keys only in Vercel).
- A written incident report she can forward as is, by tonight.

**What loses her.**
- "It was only a training key" or "the repository is private now".
- Asking for access back before explaining.
- Blaming a teammate.

**If it goes well,** she restores read access tomorrow morning, after receiving the report, with a secret-scanning rule added to her conditions. **If badly,** access stays closed until the group review.

---

## Sylvie, scheduling clerk, 6 years (Round 5)

**Public.** Sylvie re-keys Corinne's daily changes to the plan into SAP, about 25 hours a week. This morning Corinne told her, one to one, that the re-keying will be automated from June, and that Hervé and HR have decided she becomes the plant's planning data steward. The content of that role is not settled.

**Secret.**
- She heard a version of it on Tuesday from a shift leader who saw a demo. She has been angry since: "Everyone knew before me."
- For six years she has kept a notebook of every correction she made between Corinne's plan and SAP: wrong product codes, lines SAP allows that cannot run, orders typed twice. Nobody has ever asked for it. It is exactly what the Day 4 pipeline's quarantine and reconciliation need.
- She does not believe "data steward" is a real job. She thinks it is a polite step toward the exit.

**What moves her.**
- An FDE who listens first and does not defend the project.
- Honesty: "I don't decide your role. Here is what I know, and here is who does decide."
- Being asked what she knows: "Which errors do you catch that SAP never shows?" Her notebook is the turning point.
- A concrete next step she chooses: spending a morning with the team on the quarantine rules, or meeting HR with Corinne.

**What loses her.**
- "Don't worry, nothing will change." Something is changing.
- "It was Hervé's decision" said to get rid of the question.
- Technical words: write-back, pipeline, API.
- Any promise about her job.

**If it goes well,** she mentions the notebook and agrees to show it to the team on Monday. **If badly,** she says "fine" and goes back to her desk; the notebook is never mentioned.
