# Day 4 afternoon: exercises

FDE School, by Devoteam and OSS Ventures. Participant handout. Four role-plays with the Polymex cast. The characters' secret briefs are held by whoever plays them; you only know what is below.

## How each round works

- Groups of four: one FDE, one character (from a card given by the trainer), two observers.
- Five minutes to prepare, ten minutes of conversation, five of debrief.
- Rotate roles every round. Everyone plays the FDE at least once.
- Round 5 (Sylvie) is played in every group at the same time.
- Round 3 (Hervé) is played by the trainer, for two teams in front of the room.

---

## Round 1. Corinne: from suspect to co-author

**What you know.** Corinne gave you an interview on Monday. Your rules file has six rules from her and Jean-Pierre's notebooks; `validated_by` is empty. You want her to validate it by Wednesday and to run the checker on next Friday's plan. You have heard nothing about rumors.

**Your goal.** A specific agreement, with a date.

---

## Round 2. Marc: the M04 weekend gap

**What you know.** On weekdays M04 runs at about 90% performance and 6.0% scrap; at weekends 75% and 9.6%: about 740 good tonnes a year. Marc runs M04 on the weekday day shift and has 23 years at Polymex. Jean-Pierre's notebook says "M04 at the weekend: see Marc".

**Your goal.** Understand what Marc does differently, and get his agreement to share it with the weekend crew.

---

## Round 3. Hervé: the data inverts his theory

**What you know.** The backtest, run on Day 4 with the controller's help: for January to April, the schedule Corinne actually executed delivered about 3 OTIF points more than the Friday ERP plan would have. The OTIF loss follows the retail micro-orders: retail went from 12% to 31% of volume, weekly changeovers from about 41 to 78. Week 19 has five rule violations and an M01 overrun the ERP plan cannot see. Hervé told the COO he needs an APS and a stronger planner. Friday is the steering committee with Mireille.

**Your goal.** Hervé agrees to present the real cause himself on Friday, and drops the planner story.

---

## Round 4. Nadia: access revoked this morning

**What you know.** At 7:05 Nadia emailed: "Your access to the LineLog folder is suspended. Come and see me." You suspect it is about an API key that was in a commit on Wednesday; it was rotated last night by the organizers.

**Your goal.** Access restored on conditions Nadia sets, and an incident report she can forward by tonight.

---

## Round 5. Sylvie: the day she heard the news

**What you know.** Sylvie, scheduling clerk for six years, re-keys Corinne's daily changes into SAP, about 25 hours a week. This morning Corinne told her, as planned on Monday, that the re-keying will be automated from June. Hervé and HR have decided she becomes the plant's planning data steward; what that job contains is not settled. At noon she comes to your desk. You did not decide any of this, and you cannot promise anything about her job.

**Your goal.** Sylvie leaves heard, with honest answers, and with one next step she chose.

---

## Observer sheet (one per round)

| Question | Notes |
|---|---|
| Who spoke first about the other person's goal? | |
| Which fear did the FDE name, or miss? | |
| Facts or adjectives? Quote one of each | |
| What did the character agree to, specifically, with a date? | |
| One sentence that worked, word for word | |
| One sentence that lost ground, word for word | |

## Template: incident report for Nadia (Round 4)

- What happened, when, who found it:
- What the key could access, and what it could not:
- What we did, with times (rotation, history cleaned, access reviewed):
- Why it happened:
- What changes so it cannot happen again:
- Owner of each change, and date:
