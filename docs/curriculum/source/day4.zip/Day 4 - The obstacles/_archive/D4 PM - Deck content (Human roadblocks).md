<!-- DECK: FDE School, Day 4 afternoon, "Human roadblocks". 23 slides, 13:30 to 17:30. Trainer: Renan. -->
<!-- Conventions for Claude Design: slides are separated by a line of three dashes. The first comment of each slide gives its number and type. Text inside comments is design direction, never slide text. Identity: OSS Ventures design system. Ink #0D0D0D, paper #FDFDFD, flame #FD594F as the single accent; Fjalla One uppercase titles, Inter body, Archivo labels, Geist Mono for sources and figures; brand photography only. Rendered deck: "D4 PM - Deck - Human roadblocks.dc.html". -->

<!-- 1 | Title -->
# FDE School
## Day 4 afternoon: human roadblocks

FDE School, by Devoteam and OSS Ventures
Renan Devillières

*AI 50%: drafted with Claude from the FDE School curriculum and OSS field material, validated by the trainer.*

---
<!-- 2 | Hero -->
## Every system you deploy changes somebody's job. Start with that person.

---
<!-- 3 | Detail -->
## This afternoon: five conversations that decide whether Plant Pulse survives

| Time | Block | You leave with |
|---|---|---|
| 13:30 | The change curve and the fears behind it | Why people resist, and what moves them |
| 14:00 | Round 1: Corinne | From suspect to co-author |
| 14:30 | Round 2: Marc | The workaround nobody wrote down |
| 15:00 | Break | |
| 15:15 | Telling a sponsor he is wrong | The backtest, and how to use it |
| 15:35 | Round 3: Hervé | The data inverts his theory |
| 16:10 | Round 4: Nadia | Access revoked this morning |
| 16:40 | Round 5: Sylvie | The day she heard the news |
| 16:55 | Debrief | What moved each character |
| 17:15 | Close | Three things to keep |

---
<!-- 4 | Divider | ghost: FEAR -->
## Part 1. Why people resist

---
<!-- 5 | Framework -->
## People move through the change curve at their own pace, and you cannot skip a stage for them

1. **Denial.** "This will not work here."
2. **Resistance.** "It will make my job worse."
3. **Exploration.** "Show me what it does with my case."
4. **Commitment.** "I changed the rule; here is why."

---
<!-- 6 | Detail -->
## Behind every stance there is a fear you can name

| Person | What they say | What they fear |
|---|---|---|
| Corinne | "The tool will never know what I know" | Being replaced by the APS Hervé wants |
| Marc | "We have always done it this way" | Being monitored, and blamed for his workaround |
| Hervé | "I need a recommendation that holds up in front of corporate" | Losing the site in a consolidation |
| Nadia | "Not another orphan" | Being called at 3 a.m. for something she did not approve |
| Sylvie | "So the tool does my job now" | Losing her job, and her place in the team |

---
<!-- 7 | Framework -->
## Direct the rider, motivate the elephant, shape the path

- **Rider.** Clear direction: one behavior to change, not a vision.
- **Elephant.** A feeling: pride, relief, recognition. Facts alone do not move people.
- **Path.** Make the new way the easy way: the tool saves Corinne her Friday evening.

Source: Chip and Dan Heath, Switch (2010).

---
<!-- 8 | Detail -->
## Co-authorship turns the expert from a risk into the owner

- Her rules, her name in the file, her validation on every change.
- The tool checks her plan; it never writes it for her.
- She presents the result at the steering committee, not you.
- When she disagrees with the tool, the tool is wrong until proven otherwise.

---
<!-- 9 | Detail -->
## Champions are made in the first two weeks, on the night shift

- The first user is chosen for credibility on the floor, not for enthusiasm.
- Fix what they ask within a day, in front of them.
- Never use their data against their colleagues.
- Thank them in public with specifics: "Marc's setting is now the M04 standard."

---
<!-- 10 | Exercise -->
## Round 1: Corinne, from suspect to co-author

1. You need Corinne to validate the rules file and use the checker for the Friday plan.
2. She has heard that an APS will replace her.
3. One of you plays the FDE, one plays Corinne from her card, two observe.
4. Ten minutes of conversation, five of debrief with the observer sheet.

Goal: by the end, Corinne agrees to something specific, with a date.

---
<!-- 11 | Exercise -->
## Round 2: Marc, the M04 weekend gap

1. M04 loses about 740 tonnes a year at weekends; Marc runs it on weekdays.
2. You suspect a workaround the weekend crew does not apply.
3. Marc is wary of anything that sounds like monitoring.
4. Ten minutes, five of debrief. Rotate roles from round 1.

Goal: Marc tells you what he does, and agrees to make it the standard.

---
<!-- 12 | Divider | ghost: WRONG -->
## Part 2. Telling a sponsor he is wrong

---
<!-- 13 | Data -->
## The backtest clears Corinne: the schedule she runs delivers 3 OTIF points more than the official plan

- Same orders, same weeks: the Friday ERP plan against the schedule actually executed.
- Her daily overrides avoid infeasible sequences the ERP cannot see.
- The OTIF loss follows the retail micro-orders and the changeovers they cause, not the planner.

Source: Polymex backtest, Friday plans against executed schedules, January to April 2026.
<!-- single large "+3 pts" left -->

---
<!-- 14 | Framework -->
## Move the sponsor without making him lose face

1. **Pre-wire.** He hears it alone, before any meeting.
2. **Start from his goal.** OTIF at 95% and a site corporate keeps.
3. **Show the test he agreed to.** Not your opinion: the result of the branch he put in the tree.
4. **Give him the better story.** He found the real cause and acted.
5. **Ask for one decision.** A specific next step, with a date.

---
<!-- 15 | Detail -->
## Crucial conversations: facts first, then your story, then his

- Start with what you both want; say it out loud.
- State the facts you observed, without adjectives.
- Tell your interpretation as an interpretation: "I am starting to think..."
- Ask for his view, and mean it. Then listen without preparing your answer.

Source: Kerry Patterson and others, Crucial Conversations.

---
<!-- 16 | Detail -->
## Negotiate on interests, not positions

| Position | Interest behind it |
|---|---|
| Hervé: "We need an APS and a stronger planner" | Show corporate a credible plan before the group review |
| Nadia: "No access until the review is done" | Never again own a system nobody supports |
| Marc: "No camera on my line" | Not be judged on numbers he cannot explain |

Source: Roger Fisher and William Ury, Getting to Yes.

---
<!-- 17 | Exercise -->
## Round 3: Hervé, the data inverts his theory

1. You brief Hervé on the backtest before Friday's steering committee.
2. He has told the COO he needs an APS and a stronger planner.
3. The trainer plays Hervé from his card, for two teams; the others observe.
4. Ten minutes each, then the room debriefs.

Goal: Hervé agrees to present the real cause himself, and drops the planner story.

---
<!-- 18 | Exercise -->
## Round 4: Nadia, access revoked this morning

1. Nadia found an API key in a public cohort repository last night.
2. She has removed your read access to the export folder and must report to group security.
3. One of you plays the FDE lead, one plays Nadia from her card.
4. Ten minutes, five of debrief.

Goal: access restored on conditions Nadia sets, and a written incident report by tonight.

---
<!-- 19 | Exercise -->
## Round 5: Sylvie, the day she heard the news

1. This morning Corinne told Sylvie that her re-keying of the plan will be automated from June.
2. Hervé and HR have decided she becomes the plant's planning data steward. What that job contains is not settled yet.
3. Sylvie comes to the FDE team's desk at noon, upset.
4. One of you plays the FDE, one plays Sylvie from her card. Ten minutes, five of debrief.

Goal: Sylvie leaves heard, with honest answers, and with one next step she chose.

---
<!-- 20 | Detail -->
## The observer sheet: five things to watch in every round

1. Who spoke first about the other person's goal?
2. Which fear did the FDE name, or miss?
3. Facts or adjectives?
4. What did the character agree to, specifically, with a date?
5. One sentence that worked, word for word.

---
<!-- 21 | Detail -->
## What moved each character, and what lost them

<!-- complete live with the room's observations -->
- Corinne: credit and control moved her; "explain your overrides" lost her.
- Marc: his name on the standard moved him; any hint of monitoring lost him.
- Hervé: a better story for the COO moved him; being corrected in public lost him.
- Nadia: ownership of the mistake moved her; "it was only a training key" lost her.
- Sylvie: honesty and being asked for her knowledge moved her; "don't worry, nothing will change" lost her.

---
<!-- 22 | Detail -->
## Three things to keep from this afternoon

1. Name the fear behind the stance before you argue with the stance.
2. Make the expert the author; the tool checks, she decides.
3. Move a sponsor in private, from his goal, with the test he agreed to.

---
<!-- 23 | Detail -->
## Go further, and tomorrow

**Read**
- Chip and Dan Heath, *Switch* (2010).
- Kerry Patterson and others, *Crucial Conversations*.
- Roger Fisher and William Ury, *Getting to Yes*.

**Tomorrow**
- Two real engagements, disguised, in parallel. Then what really happened, your 30/60/90 plan, and the FDE Certification exam.
