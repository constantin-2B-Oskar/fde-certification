# Day 4 morning: technical roadblocks. Exercises

FDE School, by Devoteam and OSS Ventures. Participant handout. The full lab kit is in `D4 AM - Lab kit - Plant Pulse v2.zip` (repository `polymex-plant-pulse-v2`).

---

## Exercise 1. Plant Pulse v2 on the April exports (lab, 75 minutes)

**Situation.** Since Day 1, LineLog has kept exporting one file per day. Nadia copied two deliveries for you: `exports/drop_2026-04-26/` and `exports/drop_2026-05-03/`. Mireille's controller sent SAP's April output per line (`erp/production_confirmations_2026-04.csv`). Hervé wants April on the page tonight; the controller will compare.

**Build.** Raw zone with hashes and an ingest log; normalization to the Day 1 schema; seven checks with a quarantine; idempotence proven by a test; reconciliation with SAP; a data-quality report the controller can read; April on the Plant Pulse page.

**Before you code: the profile.**

| File or group of files | Encoding | Separator | Decimal mark | Units | Shift and line codes | Rows | Anything odd |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

**The three runs.**

| Run | Inputs | What you expect | What you got |
|---|---|---|---|
| 1 | Drop of 26 April | | |
| 2 | Then drop of 3 May | | |
| 3 | Drop of 3 May again | Byte-identical to run 2 | |

**Reconciliation.**

| Line | Pipeline April output, t | SAP, t | Gap % | Explanation if above 2% |
|---|---|---|---|---|
| M01 to M07 | | | | |

**The data contract.** Fill `DATA_CONTRACT.md` in the repository. The Lead takes it to Nadia (the trainer) before 11:00.

---

## Exercise 2. The naive-deployment failure memo (20 minutes)

**Situation.** Imagine that Plant Pulse v2 went live on Tuesday 14 April with your Day 1 loader, unchanged. It is now Thursday 30 April. Write the memo you owe Hervé.

**Template.**

- **What happened, answer first** (one sentence):
- **Timeline**:

| Date | What the page showed | What was true | Who noticed, when |
|---|---|---|---|
| | | | |

- **What it cost**: in decisions taken on wrong numbers, and in trust (Hervé, the controller, Corinne).
- **What would have caught each failure**:

| Failure | Check or contract clause |
|---|---|
| | |

- **What we change before we go live again**:
