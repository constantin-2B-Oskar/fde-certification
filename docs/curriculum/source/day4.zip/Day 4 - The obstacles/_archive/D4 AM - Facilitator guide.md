# Day 4 morning: technical roadblocks. Facilitator guide

*AI 50%: drafted by Claude from the FDE School curriculum and the Polymex data, validated by the trainer.* Trainer: Renan. 9:00 to 12:00. Deck: `D4 AM - Deck - Technical roadblocks.dc.html` (24 slides; content in `D4 AM - Deck content.md`). Handout: `D4 AM - Exercises.md`. Lab kit: `D4 AM - Lab kit - Plant Pulse v2.zip` (participant repository; facilitator folder with `answer_key_v2.json` and the generator).

## Objectives

By noon every participant can:

1. Recognize the seven families of plant data dirt in real files.
2. Build an idempotent pipeline: raw zone, business keys, upserts, deterministic outputs.
3. Quarantine with reasons instead of fixing silently, and report it next to every KPI.
4. Reconcile with SAP and write a data contract with the source owner.
5. Choose a move when a legacy system or a vendor says no, without crossing the IT/OT line.

## Read Nicolas's handover first

- Teams whose checker flagged the decoy: watch their quarantine rules today, same habit.
- Any leaked key: you will use it this afternoon in the Nadia role-play.

## Run sheet

| Time | Slides | Block | Notes |
|---|---|---|---|
| 9:00 | | Stand-up | Ten minutes. Roles rotate: everyone has now held three roles. |
| 9:10 | 1 to 7 | How plant data gets dirty | 20 minutes. |
| 9:30 | 8 to 13 | Pipelines that do not lie | 20 minutes. |
| 9:50 | 14 to 16 | Lab | 75 minutes, break taken inside the lab. Calls at 10:15 (profile written?), 10:40 (run 2 done?), 10:55. |
| 11:05 | 17 to 20 | Legacy and dead ends | 15 minutes. |
| 11:20 | 21 | Exercise 2 | 20 minutes. |
| 11:40 | 22 | Demos | Three minutes per team. |
| 11:55 | 23 to 24 | Close | Five minutes. |

## Slide notes

**Slide 2.** Remind the room: on Monday, the facilitator's generator planted four traps and told them to look. Today nobody tells them how many there are.

**Slide 6.** The ×560 is the naive sum of every output column in every file (about 3.96 million) against the real 7,070 t. It comes from the kilograms after 14 April and the duplicated content. Say the number, then hand out the kit.

**Slide 10.** Make one participant explain why "append" breaks with the corrected file of 9 April.

**Slide 12.** The controller's sentence is real: finance trusts a visible exclusion more than a perfect-looking total.

**Slide 19.** This is the M07 recommendation for Friday-style readouts: cheap, fast, settles the question. The works-council point returns this afternoon with Marc.

**Slide 20.** Ask the room which dead end they expect at Polymex. Answer: all six, and the release note nobody forwarded is the format-change one.

## The answer key (lab)

| Trap | Where | What a good pipeline does |
|---|---|---|
| Schema drift | All files from 14 April | Detects the second schema, maps French headers, ";" separator, CRLF |
| Units | From 14 April | Converts kilograms to tonnes; range check catches a missed conversion |
| Decimal comma | `Cadence_t_h` = "2,30" from 14 April | Parses it, or drops it in favor of the known 2.30 |
| Encoding | From 14 April, Windows-1252 | Reads "Après-midi" correctly; maps Matin, Après-midi, Nuit to A, B, C; EXT01 to M01 |
| Duplicate | 3 April, M01 shift A twice | Deduplicates on the key; logs it |
| Footer | 6 April, a TOTAL row | Rejects it as an invalid key, logs it |
| Correction | `linelog_2026-04-09_v2.csv` in the second drop | Replaces the 9 April file; M05 shift B goes from 0 to its real output |
| Late file | 22 April only in the second drop | Flagged missing after run 1; complete after run 2 |
| Impossible values | 17 April M03 shift C (run 512 > 480); 28 April M06 shift B (scrap −300 kg) | Quarantined with reasons; 628 clean machine-shifts out of 630 |

**April numbers on 628 clean rows.** Availability 70.7%, performance 86.5%, quality 93.9%, **OEE 57.5%** (down from 59.5% in Q1). Good output **6,639.6 t**, 221.3 t a day (228.7 in Q1). Changeovers: 362 in the month; ISO week 15: 82, week 16: 75, week 17: 96 (weeks 14 and 18 are partial). M07 performance stays at 77.7%; M02 availability 64.2%.

**Reconciliation with SAP.** All lines within 2%. M03 (−0.9%) and M06 (−1.6%) are lower because each has one quarantined shift that SAP counts: strong teams explain the gap with the quarantine, line by line. A team that used the first 9 April file sees M05 several points below SAP.

**After run 1 only.** 503 valid rows; 22 April and 26 to 30 April missing; M05 shift B on 9 April at zero.

## Exercise 2, model answer: the failure memo

"The Plant Pulse page has shown wrong April numbers since 14 April, and we did not see it for nine days." Then the timeline: 14 April, output jumps by a factor of a thousand on every line, the chart rescales, Corinne asks if it is a joke; the loader also stops reading shift and line codes, so the per-line view goes blank. 9 April counted twice once the correction arrives, M05 doubled for one shift. 22 April missing: the monthly average drops and looks like a bad day. 17 and 28 April impossible values pass straight to OEE. The controller's comparison with SAP fails on 23 April; Mireille hears it before Hervé does: the no-surprises rule broken. Cost: Hervé quoted a wrong OEE to the COO; Corinne stops opening the page. Each failure mapped to a check (schema, units, uniqueness, completeness, validity, reconciliation, freshness) or to a contract clause (format-change notice, correction naming). Change before go-live: the seven checks, the quarantine on the page, a freshness alert to the FDE and to Nadia, the contract signed by production.

## Demos (11:40)

Ask each team: "Run it again, now." Then: "What is in your quarantine, and who decides what happens to it?" The strongest answer names production for the content, and asks who at Polymex already knows these errors. Do not answer; Sylvie, the scheduling clerk, appears this afternoon.

## Close

Slide 23, then the card. Tell the room that the afternoon is about people, and that the four characters have been waiting since Monday.
