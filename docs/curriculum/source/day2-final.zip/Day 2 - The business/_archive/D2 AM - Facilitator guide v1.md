# Day 2 morning: problems worth solving. Facilitator guide

*AI 50%: drafted by Claude from the FDE School curriculum and the Polymex data, validated by the trainer.* Trainer: Renan. 8:45 to 12:45, four hours; lunch is shortened to 12:45 to 13:30 on Day 2. Deck: `D2 AM - Deck - Problems worth solving.dc.html` (74 slides; content in `D2 AM - Deck content.md`). Handout: `D2 AM - Exercises.md` (share in the cohort channel at 8:55).

## The three messages of the morning

1. **Change management is downstream of choosing the right problem.** A problem that never becomes a gain is meaningless, however well it is adopted.
2. **Only a big problem pays for the change it asks for.** The cost of change is roughly fixed; below a threshold, do not start.
3. **Choosing the problem is analytical and creative.** Analysis finds where the money leaks; imagination finds the lever; every idea ends on a number.

## Objectives

By 12:45 every participant can:

1. Name the main families of manufacturing (continuous, batch, discrete assembly, job shop, fast-moving consumer and fashion) and where each loses money.
2. Decompose plant performance: safety, quality, delivery, cost, cash, and OEE into availability, performance and quality.
3. Read a manufacturing P&L in twenty minutes, on Polymex and on their own organization.
4. Apply the four tests of a gain, and judge whether a problem is big enough to pay for its change.
5. Value freed capacity with the demand fork, and reframe a leak three ways with the five moves.
6. Size a leak with an assumptions table, a low and a high case, a second path, and the change it requires.

## Two things not to reveal today

1. **Corinne's overrides help.** Still hidden until Day 4. If a team writes "replace the planner" in a memo, ask: "What test would prove the planner is the cause?" Do not answer it. Watch for it in Exercise 3 and on slide 51.
2. **The consolidation rumor.** Still hidden. Reward any team that writes "why now?" as an open question for Hervé.

## Room and material

- The P&L and annex are printed on one A3 sheet per team (they are also in the handout).
- Teams keep yesterday's repositories open: the leak register reuses the Day 1 numbers.
- Whiteboard: write the five-step chain (slide 29) at 10:05, the fork (slide 39) before 10:40, the loop (slide 49) at 10:55. Leave all three up all day.
- Sticky notes and markers for Exercise 3 (silent writing).
- Tell participants the day before to bring what they know of their own organization's P&L (an annual report is enough) for Exercise 1.

## Run sheet

| Time | Slides | Block | Notes |
|---|---|---|---|
| 8:45 | | Stand-up | Ten minutes. Each team: what we learned yesterday, today's goal, one blocker. Roles rotate now. |
| 8:55 | 1 to 5 | Opening | Five minutes. Slide 5 is the bridge: five leaks, no price. |
| 9:00 | 6 to 15 | Manufacturing knowledge | 18 minutes: families, demand, performance, the P&L layers. |
| 9:18 | 16 to 23 | Read a plant P&L | 22 minutes, laptops closed, Polymex as the worked example. |
| 9:40 | 24 | Exercise 1 | 20 minutes on their own organization, 5 minutes of read-outs at 10:00. |
| 10:05 | 25 to 34 | The problem comes first | 15 minutes. The thesis of the morning. |
| 10:20 | 35 | Exercise 2 | Ten minutes in pairs, keep or kill. |
| 10:30 | | Break | Ten minutes. |
| 10:40 | 36 to 43 | Bottleneck and demand fork | 15 minutes. |
| 10:55 | 44 to 54 | Analysis and imagination | 20 minutes. |
| 11:15 | 55 | Exercise 3 | 15 minutes: five silent, ten as a team. |
| 11:30 | 56 to 60 | Size in euros | 10 minutes. |
| 11:40 | 61 to 68 | Choose the problem worth the change | 10 minutes. |
| 11:50 | 69 to 71 | Exercise 4, lab | 35 minutes. Calls at 12:05 (register rows complete?), 12:15 (memo started?), 12:20. |
| 12:25 | 72 | Demos | Three minutes per team, five teams. |
| 12:40 | 73 to 74 | Close | Five minutes. |

If you are late, cut slides 65 to 67 to one minute each and Exercise 3 to ten minutes; never cut the lab, the knowledge block or Part 2.

## Slide notes

### Opening (slides 1 to 5)

**Slide 2.** Let the line sit. Then: "Yesterday you found M07 losing 376 tonnes. Is that a lot? Nobody in this room can answer yet. By lunch you will."

**Slide 5.** Read one row aloud and ask the room what it is worth. Collect three guesses on the whiteboard. You will come back to them at 12:25.

### Manufacturing and its P&L (slides 6 to 23)

Forty minutes, laptops closed. The first eighteen minutes are the knowledge block (slides 7 to 15): plant families, how a plant meets demand, plant performance and the shape of a manufacturing P&L. Then the P&L reading on Polymex as the worked example (slides 16 to 23). Participants need this before they can judge any candidate problem in Part 2.

**Slides 7 and 8.** Ask each participant which family their own organization belongs to. Keep the answers: they come back in Exercise 1. Polymex is batch process, make to order on most grades.

**Slide 9.** The point is cash and lead time. Make to stock carries inventory; make to order makes the customer wait. Most plants are a mix by product family.

**Slide 10.** This is the bridge to Part 2: regulation raises the cost of change, so the same problem can be worth solving in a compounder and not in a pharma plant.

**Slide 11.** The daily shop-floor meeting runs in this order. If you open with cost, the site director stops listening.

**Slides 12 and 13.** Walk the ladder from the bottom. Then place each of yesterday's five leaks on one of the six losses. M07 micro-stops are the classic hidden loss: performance, not availability.

**Slide 14.** Do not oversell the 85%: it is a reference, and comparing OEE across plants with different definitions is a trap. Ask: "Which factor would you attack first at Polymex, and why?" Availability.

**Slide 15.** Three layers. The site director is judged on the first two; the third is politics.

**Slide 20.** Variances are how a controller already talks about the plant. Usage and absorption variances are where operational leaks show up first.

**Slide 22.** Absorption is the one to insist on: building stock improves the plant margin on paper while it consumes cash. Ask the room why a director might like that at year end.


**Slide 16.** Make the room classify three lines live: energy (mostly variable), maintenance (mostly fixed, with a variable share), direct labor (fixed, except the overtime premium). The point is not precision; it is the reflex of asking.

**Slide 17.** Materials at 60% of revenue changes how you see scrap: a scrap point at Polymex is about €0.9M of resin before any capacity effect.

**Slide 18.** The most important number of the morning. Write €447 on the whiteboard next to the fork. Ask: "Hervé says a tonne is worth €1,721. Why is he wrong?" Then: "The controller's full cost is €1,608. Why must you never value a freed hour with it?" Because fixed costs do not move when you free an hour.

**Slide 19.** Do not read the lines. Point at three: overtime premium (a symptom), scrap disposal inside consumables (the visible tip of scrap), and allocated SG&A (politics, not operations).

**Slide 21.** Insist on move 5. People who explain a plant to you anchor you on their theory. Hervé's theory is planning.

**Slide 23.** Ask one participant to define OTIF. Then ask: "Against what date?" Most will not know that OTIF on promise date and on request date can differ by ten points.

### Exercise 1, guidance (slide 24)

Participants work on their own organization: the one they come from, or for those in a services firm, the last manufacturer they worked with. There is no model answer; judge the method.

- Strong: the family is named, the P&L is sketched with orders of magnitude, each hypothesis carries a number and a question for the controller.
- Weak: "costs are too high", "IT is old". Push for the number and the P&L line.
- Confidentiality: participants describe their organization in orders of magnitude only. Nothing leaves the room.

After the read-outs at 10:00, show the Polymex reference hypotheses below as a model of what a strong hypothesis looks like.

### Polymex reference hypotheses (show after the Exercise 1 read-outs)

Use these to show what a strong hypothesis looks like on a plant P&L, after participants have read out their own. Three strong hypotheses, each with its number and its first question:

| Hypothesis | The number | First question for the controller |
|---|---|---|
| Scrap is the biggest recurring leak | 4.2% of €89.2M of material input, plus €0.15M disposal | Is regrind recovered, and is the 4.2% net or gross of it? |
| Changeovers are eating the capacity buffer and the OTIF | 11.5% of scheduled hours, count doubled since January; OTIF 87% and slipping; overtime on Fridays | How is changeover time measured, and since when? |
| Inventory is too high for the sector | DIO 78 days against about 55 for peers | Which families hold the excess, and is any of it obsolete? |

Acceptable alternatives: energy intensity (ask for kWh per tonne by line), maintenance (ask for the planned against reactive split). Weak answers: "costs are too high", "labor is expensive". Push them to a number.

### The problem comes first (slides 25 to 35)

The thesis of the morning. Everything after this block is about choosing well; this block says why choosing comes before everything else, including change management.

**Slide 26.** Let it sit. Then ask: "Name a project you saw that delivered something and gained nothing." Take two answers. Dashboards always come up.

**Slide 27.** The four tests. Insist on the second: a baseline reconstructed after the fact is the first thing a CFO attacks.

**Slide 28.** Walk the five rows fast. Row four connects to the demand fork you will draw at 10:40: freed capacity in a plant that cannot sell it is not a gain.

**Slides 29 and 30.** The order matters. Participants arriving from consulting or IT tend to start at step 3 or 4: a training plan, an adoption campaign. Say plainly: change management is necessary and it is downstream. It cannot turn a badly chosen problem into money.

**Slide 31.** Second thesis. Read it, then go straight to slide 32.

**Slide 32.** Ask the room which row they would forget. Usually the transition dip: output drops while people learn, and a small project never recovers it.

**Slide 33.** The core argument for why change management only works on big problems: the cost of change is roughly fixed, the gain is not. Below a threshold the honest answer is not to start.

**Slide 34.** Give one example per bullet from your own field experience. Keep "kill it out loud": it returns in the lab memo.

### Exercise 2, model answer (slide 35)

| Candidate | Who must change | Where the gain lands | Verdict |
|---|---|---|---|
| A. Automate the daily production report | Shift leaders stop typing it | Nowhere: about 365 hours a year, a fifth of a person, and nobody leaves | Kill, unless bundled as an enabler |
| B. Cut scrap on extrusion | Operators, process engineers, quality: start-up routines and setpoints | Materials line: 4.2% of €89.2M of input; a 30% cut is about €1.2M a year | Keep. Big, cost-out, the controller can sign it |
| C. Predict M02 failures | Maintenance moves from reactive to planned | Avoided overtime today; contribution only if sales takes the tonnes | Keep, conditional on the fork. Size it in Part 3 |
| D. An OEE screen on every line | Nobody, unless a routine acts on it | Nowhere on its own | Kill as a project; keep as a tool inside B or C |

The point to land: two of four candidates have no gain at all, and they are the two that look easiest to build.

### Bottleneck and demand fork (slides 36 to 43)

**Slide 37.** One field story: a team spent six weeks speeding up a packing line that was starved half the day. Zero tonnes gained. The lesson: find the constraint before you touch anything.

**Slide 38.** The participants found this yesterday. Make them say it, not you.

**Slide 39.** Draw it on the whiteboard as a fork with three branches. This is the single concept the exam tests most in this module.

**Slide 40.** The nuance that separates strong teams: Polymex is not sold out, so freed hours are worth little directly, but the lead-time unlock is real and capped at 5,160 t a year (6% of 86,000 t). Ask: "Who must confirm the 6% in writing?" The sales director, with named accounts.

**Slide 41.** Walk the arithmetic once. 61,320 h × 1% × 2.30 × 0.863 × 0.939 = 1,143 t.

**Slide 43.** The decoy. In the original three-week curriculum, teams that sized overtime as a fourth leak lost a point. Say so.

### Analysis and imagination (slides 44 to 55)

The second message of the morning: choosing the problem is a mix of analytical and creative thinking. The P&L and the fork are the analytical half; this block is the creative half, and it ends back on a number.

**Slide 45.** Read the two lines aloud as one idea, not two. Neither mode is enough.

**Slide 46.** Use the last row. Analysts fail by optimizing today's way of working; creatives fail by producing ideas nobody can price.

**Slide 47.** The Polymex line is the bridge: the logs show changeovers getting longer, but the cause of the doubling sits outside the logs, in the order book.

**Slide 49.** Draw the loop on the whiteboard next to the fork. Point out it starts and ends in analytical mode.

**Slide 50.** Run "invert" live with the room on overtime: "How would we double Polymex's overtime?" Answers point at late plans and changeovers, which is what slide 43 said.

**Slide 51.** The slide that makes creativity concrete. Each framing gives a different lever and a different owner. Do not let anyone conclude that the planner is the cause: the sequencing framing is one hypothesis among four, and Day 4 tests it.

**Slide 52.** Shingo's insight was a question, not a measurement. Make the order explicit: new question first, numbers second.

**Slides 53 and 54.** Run Exercise 3 with these rules. Enforce the five minutes of silent writing.

### Exercise 3, what good looks like (slide 55)

For M04 at weekends, three framings that each change the lever or the owner:

| Framing | Owner | First number to check |
|---|---|---|
| A skills problem: the weekend crew does not run M04 the weekday way | Shift leaders, training | Performance and scrap by operator on weekends |
| A support problem: no maintenance cover at weekends, so stops last longer | Maintenance | Stop duration on M04, weekend against weekday |
| A material problem: weekend runs use a different grade or lot | Planning, quality | Grades run on M04 at weekends against weekdays |

Weak answers restate the same framing in different words ("the weekend crew is less motivated", "the weekend crew is less experienced"). Ask: "Which lever does that change?" Do not reveal Marc's weekday workaround: it is the Day 4 hypothesis.

### Size in euros (slides 56 to 60)

**Slide 58.** The "Who confirms" column is what turns a guess into a plan. Every assumption has a name next to it.

**Slide 59.** The most common error in gains cases. Make the room say the correct sentence aloud: "€10M of cash once, and €1.8M a year."

**Slide 60.** The triangulation example is real in the data. Both numbers are right on their own perimeter: the annex covers twelve months and all scheduled hours; the logs cover extrusion in Q1. The answer is a question for the controller, not a choice.

### Choose the problem worth the change (slides 61 to 68)

**Slide 62.** The five criteria from the original version, with "the change included" added to Big. Point back to slide 33.

**Slide 63.** Ask where each Exercise 2 candidate sits. A and D are small gain; B is big gain, heavy change; C depends on the fork.

**Slide 64.** Net gain is the gain after the cost of change. Confidence and change load usually decide between two candidates of similar size.

**Slides 65 to 67.** Keep this short. The message: Polymex is one site of a group. The first problem must produce a gain Mireille signs, and the pipeline and ontology must be reusable at a sister site. Hint, without revealing the rumor: "If the group were comparing sites, which number would it compare?"

**Slide 68.** The kill list goes into the lab memo. Teams that skip it lose the argument in month three.

## Exercise 4, model answer (lab)

The facilitator answer key. Numbers from the Day 1 logs are annualized from Q1 2026 (× 365 / 90) and must be labeled as such.

### Unit economics

| Item | Value |
|---|---|
| Contribution margin | €447 per tonne (26% of €1,721) |
| One point of extrusion availability | 1,143 good tonnes a year |
| Sellable extra volume | 5,160 t a year (6% of 86,000 t), only if lead times improve, to be confirmed by sales |
| Value cap of all capacity leaks together | 5,160 t × €447 ≈ €2.3M a year |

### Capacity leaks from the logs

| Leak | Physical effect, annualized | Note |
|---|---|---|
| Changeovers | 10.3% of planned time in March; a 40% SMED reduction frees 4.1 points, about 4,700 t a year. At the January rate instead of March, the gap is 272 t a month, about 3,300 t a year | The OTIF story; changeover count rose with retail orders |
| M07 micro-stops | 376 t in Q1, about 1,525 t a year at fleet performance | Unlogged: performance is low while logged downtime is normal |
| M02 downtime | 8.4 points above the fleet on M02: 180 h and 344 t in Q1, about 1,400 t a year | Ask maintenance for the failure log |
| M04 at weekends | 183 good tonnes in Q1 at weekday rates, about 740 t a year | Performance and scrap both worse; Marc's weekday workaround is the hypothesis for Day 4 |
| Shift C | Performance 83.9% against 87.5%: about 310 t of output in Q1 | Overlaps with the machine rows; do not add it |

Total identified capacity: about 8,300 t a year, against 5,160 t sellable. **The capacity leaks cannot be summed at €447.** Their joint value is capped at about €2.3M a year by demand, and only once sales confirms the volume. Below the cap, they are worth avoided overtime. Strong teams write this sentence.

### Leaks from the P&L and annex

| Leak | Size | Type |
|---|---|---|
| Scrap | 4.2% × €89.2M ≈ €3.75M of material, plus €0.15M disposal: **€3.9M a year** of leak. Addressable base case 30%: about €1.2M a year (range 20 to 40%) | Recurring cost-out. Its capacity effect is already inside the 94% quality rate: do not count it again |
| Inventory | (78 − 55) / 365 × COGS €123.8M ≈ **€7.8M of cash, once**, plus 18% carrying ≈ **€1.4M a year** | One-time cash and recurring carry, stated separately |
| Overtime premium | €0.9M a year | Symptom of changeovers and planning. Count only the share not already bought back by the capacity rows; the base case counts zero |

### The ranking we expect

1. **Scrap: €3.9M a year of leak**, of which about €1.2M addressable in the base case. Cost-out, the easiest gain to validate.
2. **Changeovers and machine losses: up to €2.3M a year**, capped by the sellable 6% and conditional on sales confirmation. It is also the OTIF fix.
3. **Inventory: €7.8M of cash once and €1.4M a year of carrying cost.**

Debrief punchline: "€7 to 8M of recurring value sits inside a plant that earns €9.7M of EBIT. This is why the job exists."

### Scoring grid for the debrief (no marks this week, use it to give feedback)

| Dimension | What good looks like |
|---|---|
| Arithmetic | Shown, with an assumptions table and sources |
| The demand fork | Applied explicitly; capacity capped by the 5,160 t |
| Double counts | Overtime named as a symptom; shift C not added to machine rows; scrap capacity not counted twice |
| Memo | Answer first; three leaks; one question each; a director would read it |

### Common failures to name in the debrief

- Valuing freed tonnes at €1,721 (price) or €1,608 (full cost).
- Summing all capacity leaks at €447 per tonne: €3.7M that the market cannot absorb.
- "€9.2M of inventory savings": cash and carry added together.
- Annualizing a quarter without saying so, or annualizing March as if it were the year.

## Demos (12:25)

Three minutes per team, live. After each, one question from you: "Who confirms your biggest assumption?" Then return to the three guesses written at 8:55 and compare.

## Close (12:40)

Slide 73, then the card: "one thing I would do differently on a real site". Remind teams that this afternoon's charter builds on this register.

## Trainer retro, after the day

Which team still values capacity at price? Pair them with a strong Verifier this afternoon.
