<!-- DECK: FDE School, Day 2 morning, "Problems worth solving". 74 slides, 8:45 to 12:45. Trainer: Renan. -->
<!-- Conventions for Claude Design: slides are separated by a line of three dashes. The first comment of each slide gives its number and type. Text inside comments is design direction, never slide text. Identity: OSS Ventures design system. Ink #0D0D0D, paper #FDFDFD, flame #FD594F as the single accent; Fjalla One uppercase titles, Inter body, Archivo labels, Geist Mono for sources and figures; brand photography only. Rendered deck: "D2 AM - Deck - Problems worth solving.dc.html". -->

<!-- 1 | Title -->
# FDE School
## Day 2 morning: problems worth solving

FDE School, by Devoteam and OSS Ventures
Renan Devillières

*AI 50%: drafted with Claude from the FDE School curriculum and OSS field material, validated by the trainer.*



---
<!-- 2 | Hero -->
## Nobody funds a problem without a price.



---
<!-- 3 | Detail -->
## This morning: understand the plant and its P&L, choose the problem, then price it

| Time | Block | You leave with |
|---|---|---|
| 8:45 | Stand-up | Yesterday in one sentence per team |
| 9:00 | Manufacturing and its P&L, Exercise 1 | Plant families, plant performance, the P&L read on your own organization |
| 10:05 | The problem comes first, Exercise 2 | Why change is downstream; keep or kill four candidates |
| 10:30 | Break, then the bottleneck and the demand fork | What a freed hour is worth |
| 10:55 | Analysis and imagination, Exercise 3 | Five reframing moves; three framings of one leak |
| 11:30 | Size in euros, choose the problem worth the change | The assumptions table; gain against change load |
| 11:50 | Lab, demos and close | A ranked leak register and a one-page memo |

---
<!-- 4 | Detail -->
## By 12:45 you will choose and price a problem the way a plant controller and a sponsor would

- You can tell a continuous plant from a batch plant or an assembly line, and say where each loses money.
- You can read a manufacturing P&L in twenty minutes, and you have done it on your own organization.
- You can say why a problem that never becomes a gain is worth nothing, and whether it is big enough to pay for its change.
- You know what one more tonne is worth at Polymex, and why the answer depends on demand.
- You can reframe a leak three ways and price each framing.
- Your team has a ranked leak register and a one-page memo for Hervé.

---
<!-- 5 | Data -->
## Yesterday you found five leaks in the shift logs; none of them has a price yet

| Leak | Evidence, January to March 2026 |
|---|---|
| Changeovers | 7.5% of planned time in January, 10.3% in March |
| M07 | Performance 77.6% against 88% for the fleet: 376 t lost in the quarter |
| M04 at weekends | Performance 75% against 90% on weekdays, scrap 9.6% against 6.0% |
| M02 | Unplanned downtime 16.1% of planned time, against 7.7% for the other lines |
| Shift C | Performance 83.9% against 87.5% for shifts A and B |

Source: Polymex extrusion shift logs, Q1 2026, cleaned (Day 1 lab).



---
<!-- 6 | Divider | ghost: P&L -->
## Part 1. Manufacturing and its P&L



---
<!-- 7 | Detail -->
## Manufacturing comes in families, and each family optimizes something different

| Family | Examples | What the plant optimizes |
|---|---|---|
| Continuous process | Refining, steel, glass, paper, base chemicals | Uptime, energy, yield |
| Batch process | Pharma, food, specialty chemicals, plastics compounding | Changeovers, batch yield, release time |
| Discrete assembly | Automotive, aerospace, machinery, electronics | Line balance, part availability, rework |
| Job shop and engineer to order | Machining, capital equipment, shipbuilding | Lead time, scheduling, quoting accuracy |
| Fast-moving consumer and fashion | Apparel, cosmetics, consumer electronics | Forecast, speed to shelf, markdowns |

---
<!-- 8 | Detail -->
## Each family leaks money in its own places, so the first use case differs too

| Family | Where money usually leaks | Where FDE work usually lands |
|---|---|---|
| Continuous process | Unplanned stops, grade transitions, energy, off-spec at start-up | Predictive maintenance, setpoint advice, energy |
| Batch process | Changeovers and cleaning, failed batches, waiting for quality release | Scheduling, batch record review, yield |
| Discrete assembly | Missing parts, line stoppages, rework, work in progress | Shortage prediction, vision inspection, line balancing |
| Job shop and engineer to order | Late orders, overruns against quote, idle bottleneck machines | Quoting from history, finite scheduling |
| Fast-moving consumer and fashion | Forecast error, obsolete stock, markdowns, airfreight | Demand sensing, allocation, size curves |

---
<!-- 9 | Framework -->
## How a plant meets demand decides where the cash sits and how long the customer waits

- **Make to stock.** Built ahead on a forecast. Fast delivery, inventory risk. Consumer goods, base chemicals.
- **Make to order.** Built when the order arrives. Little finished stock, longer lead times. Compounders, converters.
- **Assemble to order.** Modules in stock, final assembly on order. Trucks, PCs, configurable machines.
- **Engineer to order.** Designed for each customer. Long lead times, project risk. Capital equipment, ships.

---
<!-- 10 | Detail -->
## Regulated plants change slowly, and that raises the bar for a problem worth solving

- In pharma, any change to a validated process or system needs documented requalification under GMP.
- Food plants answer to traceability and hygiene rules; aerospace and medical devices to part qualification.
- So the cost of change is higher there, and a problem must be bigger to pay for it.
- Problems outside the validated core, such as scheduling, release lead time or warehouse flows, often move faster.

---
<!-- 11 | Framework -->
## A plant is judged on five dimensions, always in the same order: safety, quality, delivery, cost, cash

- **Safety.** Accidents and near misses. Never traded against anything else.
- **Quality.** Scrap, rework, customer claims, first-pass yield.
- **Delivery.** OTIF, lead time, schedule adherence.
- **Cost.** Cost per unit, productivity, energy per unit, overtime.
- **Cash.** Inventory days, working capital, capex.

---
<!-- 12 | Framework | ladder -->
## OEE splits the plant's time into layers, and each layer has its own losses

1. **Calendar time.** 24 hours a day, 365 days a year.
2. **Planned time.** Minus planned closures: weekends off, holidays, planned maintenance.
3. **Run time.** Minus availability losses: breakdowns, changeovers. Availability is run time over planned time.
4. **Net run time.** Minus performance losses: micro-stops, reduced speed. Performance is actual output over output at the ideal rate.
5. **Good output.** Minus quality losses: scrap, rework, start-up rejects. Quality is good output over total output.

---
<!-- 13 | Detail -->
## The six big losses: where each point of OEE goes

| Loss | OEE factor | Example at Polymex |
|---|---|---|
| Breakdowns | Availability | M02 failures |
| Setups and adjustments | Availability | Changeovers between grades and colors |
| Small stops | Performance | M07 micro-stops, never logged as downtime |
| Reduced speed | Performance | Running below the ideal rate to avoid defects |
| Start-up rejects | Quality | Scrap in the first minutes after a changeover |
| Production rejects | Quality | Off-spec during steady running |

---
<!-- 14 | Data -->
## Polymex runs at 61% OEE, against the 85% usually quoted as world class

- Availability 74% × performance 88% × quality 94% = 61%.
- The 85% benchmark comes from Seiichi Nakajima's work on TPM; most plants run well below it.
- Availability is Polymex's weakest factor: changeovers and breakdowns come before speed or scrap.

Source: Polymex operational annex; Seiichi Nakajima, Introduction to TPM (1988).
<!-- single large "61%" left -->

---
<!-- 15 | Framework -->
## A manufacturing P&L stacks three layers: making, running the plant, and what the group adds

1. **Cost of goods sold.** Materials, direct labor, energy, plant overhead and depreciation. Revenue minus COGS is the gross margin.
2. **Plant and logistics costs.** Freight, warehousing, site support. What the site director controls.
3. **Group charges.** Allocated SG&A, royalties, central services. Know them, do not fight them.

---
<!-- 16 | Framework -->
## Revenue is volume times price times mix; every cost is variable or fixed

| Line | What to ask |
|---|---|
| Revenue | Volume trend first, then price, then mix. Mix shifts explain half of everything else. |
| Variable costs | Move with volume: materials, energy, consumables, freight, overtime premium. |
| Fixed costs | Do not move on the planning horizon: salaried labor, depreciation, most maintenance. |
| Contribution margin | Revenue minus variable costs. The answer to "what is one more unit worth?" |
| Plant EBIT | What the director is judged on. Corporate allocations sit on top: know them, do not fight them. |



---
<!-- 17 | Data -->
## Materials are 60% of Polymex's revenue, so scrap is a materials story before it is a quality story

- Resins, additives and pigments cost €89.2M on €148.0M of revenue.
- In process industries materials are typically 50 to 70% of cost.
- A 4.2% scrap rate on €89.2M of material input is €3.7M of resin thrown away each year, before counting the capacity that produced it.

Source: Polymex plant P&L and operational annex, last twelve months.
<!-- single large "60%" left -->



---
<!-- 18 | Framework -->
## One more tonne sold at Polymex is worth about €447, not €1,721

| Step | Per tonne |
|---|---|
| Average selling price | €1,721 (€148.0M for 86,000 t) |
| Variable costs | €1,274: materials, energy, consumables, freight, variable share of labor and maintenance |
| Contribution margin | €447, about 26% of the price |
| Full cost, for comparison | €1,608: the number you must never use to value a freed hour |

Source: Polymex plant P&L, last twelve months; contribution rate agreed with the plant controller.



---
<!-- 19 | Detail -->
## Polymex earns €9.7M of EBIT on €148M of revenue

| Line | €M | Notes |
|---|---|---|
| Revenue | 148.0 | 86,000 t, €1,721/t |
| Materials | (89.2) | Resins, additives, pigments |
| Direct labor | (14.6) | Of which overtime premium 0.9 |
| Energy and maintenance | (10.9) | Energy 6.8; maintenance 4.1, internal and contractors |
| Consumables and other variable | (3.9) | Includes scrap disposal 0.15 |
| Depreciation | (5.2) | |
| Plant gross margin | 24.2 | 16.4% |
| Logistics and freight | (4.7) | |
| Allocated SG&A | (9.8) | Corporate allocation |
| Plant EBIT | 9.7 | 6.6% |

Source: Polymex plant P&L, last twelve months.



---
<!-- 20 | Framework -->
## Controllers report against standard cost, and the variances tell the operational story

| Variance | What it tells you |
|---|---|
| Material price | Bought dearer or cheaper than standard: purchasing, not the shop floor |
| Material usage | More material used than the recipe says: scrap, giveaway, yield |
| Labor efficiency | More hours than the routing allows: slow lines, rework, poor flow |
| Volume or absorption | Fewer units than planned to carry the fixed costs: the plant ran below plan |

---
<!-- 21 | Framework -->
## Read any plant P&L in twenty minutes, in five moves

1. **Revenue.** Volume trend and mix shift first.
2. **Gross margin.** Against last year and against the sector.
3. **Operational annex.** OEE, scrap, OTIF, inventory days, before any more cost lines.
4. **Anomalies.** Any line moving faster than volume.
5. **Three hypotheses.** Written before anyone explains the plant to you.



---
<!-- 22 | Detail -->
## Speak the controller's vocabulary as well as the director's

| Term | Meaning, and the question to ask |
|---|---|
| COGS | Cost of goods sold. What sits inside it: depreciation, freight? |
| Standard cost | The planned cost per unit. When was it last updated? |
| BOM and routing | The recipe, and the steps and times per unit. Who maintains them? |
| Absorption | Fixed costs spread over units made. Building stock flatters the margin on paper |
| EBITDA | Earnings before interest, taxes, depreciation and amortization: the group's favorite plant number |
| Working capital | Inventory plus receivables minus payables: the cash tied up in running the business |
| Capex and opex | Capitalized spend against spend in this year's P&L. Which one pays for your project? |

---
<!-- 23 | Detail -->
## Speak the director's vocabulary without notes by Friday

| Term | Meaning, and the question to ask |
|---|---|
| OTIF | On time, in full. Against the promise date or the request date? |
| Demonstrated capacity | What the plant has actually produced at its best sustained rate, not the nameplate |
| Takt | Available time divided by customer demand: the pace the plant must hold |
| MTBF and MTTR | Mean time between failures, mean time to repair |
| First-pass yield | Good the first time, without rework. Rework hides between first-pass and final yield |
| DIO | Days of inventory outstanding, against sector peers |
| Frozen horizon | The days of the schedule nobody is allowed to change |



---
<!-- 24 | Exercise -->
## Exercise 1: read your own organization's P&L and commit to three hypotheses

1. Sketch its P&L: revenue, variable costs, fixed costs, margin. Use the latest annual report or what you know of the management accounts.
2. Name its family and the performance dimension it is judged on first.
3. Write three hypotheses about where it loses money, each with the number or order of magnitude that makes you suspicious.
4. For each, write the first question you would ask its controller.

Twenty minutes, alone then in pairs. If you work for a services firm, take the last manufacturer you worked with. Three people read one hypothesis aloud at 10:00.

---
<!-- 25 | Divider | ghost: FIRST -->
## Part 2. The problem comes first


---
<!-- 26 | Hero -->
## A problem that never turns into a gain is meaningless.


---
<!-- 27 | Detail -->
## A gain exists only when four things are true at the same time

- **It lands in the books.** A P&L line or a cash line moves, and the controller can point to it.
- **The baseline was agreed before.** Measured against a number both sides signed at the start, not reconstructed afterwards.
- **Someone works differently.** A planner, an operator or a technician changed a decision they make every day.
- **It lasts.** The gain is still there three months after the FDE has left the site.


---
<!-- 28 | Detail -->
## Most of what projects deliver is not a gain yet

| Delivered | Why it is not a gain | What would make it one |
|---|---|---|
| A dashboard | Nobody's decision changed | A named person acts on it every shift, and the action has a price |
| A model with 95% accuracy | Accuracy is not money | A decision taken on the prediction, and the cost it avoided |
| Hours saved for shift leaders | Nobody leaves and nothing else gets done | The hours are redeployed to a task with a value |
| Capacity freed at the constraint | The plant cannot sell the tonnes | Sales names the orders, or the hours replace overtime |
| An insight in a deck | Nobody owns the next step | An owner, a date and a target in the plan |


---
<!-- 29 | Framework -->
## Change management is downstream of the problem you choose

1. **Choose the problem.** Big, measurable, controllable, owned, urgent.
2. **Price the gain.** In euros, with every assumption visible.
3. **Design the change.** Who works differently, from when, with what support.
4. **Run the change.** Training, routines, follow-up on the floor.
5. **Sign the gain.** The controller confirms it against the baseline.


---
<!-- 30 | Detail -->
## Get step one wrong and the best change program has nothing to carry

- Change management cannot rescue a problem that was too small, unmeasurable or out of the plant's hands.
- It can only make a well-chosen problem pay out faster and for longer.
- So the effort you spend choosing is the cheapest effort of the whole engagement.
- The question to ask before any training plan: "If everyone adopts this perfectly, what does the controller book?"


---
<!-- 31 | Hero -->
## Only a big problem pays for the change it asks for.


---
<!-- 32 | Detail -->
## Price the change, not only the build

| Cost of change | What it means on a plant | Who pays it |
|---|---|---|
| Learning | Every planner, shift leader and operator trained, across three shifts and the weekend crew | The people on the floor, in hours and in stress |
| Routines | Meetings, standard work and handovers rewritten | Supervisors and the site director |
| Transition dip | Output and quality often drop while people learn the new way | The plant P&L, for weeks |
| Sponsor attention | Time in steering committees, credibility in the group review | The site director |
| Trust | If it fails, the next project starts lower | Everyone, including you |


---
<!-- 33 | Detail -->
## The cost of change barely depends on the size of the prize

- Retraining three shifts costs the same for a €100k problem as for a €2M one.
- People change a routine when the reason shows on their own scoreboard. A small gain does not show.
- A sponsor defends a project in the group review only if it moves the number he is judged on.
- A small project loses to Monday morning's breakdown, every Monday.
- So below a certain size the change costs more than the gain, and the honest answer is not to start.


---
<!-- 34 | Detail -->
## When the right problem is too small, make it bigger or pick another

- **Sum the sister sites.** The same changeover problem across four plants may be worth the change once the pipeline is reused.
- **Bundle the neighbor.** Scrap and start-up losses after changeovers often share the same root and the same people.
- **Move up the chain.** A small quality problem can be a big customer-claims problem.
- **Or kill it out loud.** Write in the memo what you chose not to do, and why.


---
<!-- 35 | Exercise -->
## Exercise 2: keep or kill four candidate problems at Polymex

1. For each candidate in the handout, name who must change how they work.
2. Say where the gain lands in the P&L, or write "nowhere".
3. Keep or kill. A kill needs one sentence; a keep needs a rough size.

Ten minutes, in pairs. Two pairs read out their kills.


---
<!-- 36 | Divider | ghost: FORK -->
## Part 3. The bottleneck and the demand fork



---
<!-- 37 | Hero -->
## An hour lost at the bottleneck is lost for the whole plant. An hour saved anywhere else is a mirage.



---
<!-- 38 | Framework -->
## The constraint sets the plant's output, and at Polymex the constraint is extrusion

| Stage | Daily minutes, average over Q1 2026 |
|---|---|
| Mixing | Starved 60, blocked 1,169: waiting for extrusion to take its batches |
| Extrusion | Starved 34, blocked 25: always busy, never waiting |
| Packing | Starved 1,658, blocked 35: waiting for extrusion to feed it |

Upstream blocked, downstream starved, the constraint busy: the textbook signature. Every improvement this week targets extrusion.

Source: Polymex stage daily file, Q1 2026 (Day 1 lab).



---
<!-- 39 | Framework -->
## What a freed hour is worth forks on one question: is the plant sold out?

| Situation | A freed hour at the constraint is worth |
|---|---|
| Sold out | The contribution margin of the extra tonnes, once sales confirms it can sell them |
| Not sold out | Only the variable cost it avoids: overtime, weekend shifts, outsourcing |
| Not sold out, but lead time loses orders | The contribution of the orders that shorter lead times win, if sales can name them |

Ask "what is your order book against demonstrated capacity?" in the first hour of every engagement.



---
<!-- 40 | Data -->
## Polymex is not sold out, but two accounts would take 6% more volume if lead times improved

- Order book: 91% of demonstrated capacity.
- Sales: two retail accounts would take +6% volume at current prices with shorter lead times.
- So a freed hour is worth avoided overtime today, and up to the contribution of 5,160 t a year if the lead time improves.

Source: Polymex operational annex; sales director, interview notes.
<!-- single large "91%" left -->



---
<!-- 41 | Data -->
## One point of extrusion availability is worth about 1,143 tonnes of good output a year

- Planned time: 7 lines × 3 shifts × 8 hours × 365 days = 61,320 hours a year.
- One point is 613 hours, at 2.30 t/h ideal, 86.3% performance and 93.9% quality.
- That is 1,143 good tonnes, worth €0.5M a year only if the plant can sell them.

Source: Polymex shift logs Q1 2026; Day 1 OEE definitions.
<!-- one large figure "1,143 t" left -->



---
<!-- 42 | Framework -->
## Plants leak money through five families, and the last one is usually a symptom

- **Scrap and quality.** Material, plus the capacity that produced it. First-pass yield beats final yield.
- **Changeovers.** Capacity and start-up scrap. SMED discipline often removes 30 to 50% of changeover time.
- **Unplanned downtime.** The logged number is a floor; micro-stops hide below it.
- **Inventory.** Cash released once, carrying cost of 15 to 25% a year saved every year.
- **Expedites and overtime.** Almost always the visible symptom of the other four plus planning.



---
<!-- 43 | Detail -->
## Count every euro once: overtime and expedites are symptoms, not a sixth leak

- Polymex pays €0.9M of overtime premium, concentrated on Fridays and month-end.
- Those hours buy back capacity lost to changeovers and late plans.
- Size them separately and you count the same tonne twice.
- Name the double count out loud in your memo. A controller will look for it first.



---
<!-- 44 | Divider | ghost: IDEA -->
## Part 4. Analysis and imagination


---
<!-- 45 | Hero -->
## Analysis finds where the money leaks. Imagination finds the way to stop it.


---
<!-- 46 | Detail -->
## Choosing a problem takes two modes of thinking, used one after the other

| | Analytical | Creative |
|---|---|---|
| The question | Where exactly, how much, how sure? | What else could this be? |
| The moves | Decompose, measure, size, falsify | Reframe, invert, borrow, combine |
| The output | One number with a range | Many options, most of them wrong |
| How it fails | Optimizes inside today's way of working | Produces ideas nobody can price |


---
<!-- 47 | Detail -->
## Analysis alone finds the leak everyone already knows

- The data shows only what the plant chose to measure. Micro-stops and workarounds live outside it.
- It ranks the problems inside the current way of working and never questions the way of working.
- It gives every team the same answer from the same P&L, so it gives you no edge.
- At Polymex the logs say changeovers take longer. They do not say why the plant now runs twice as many.


---
<!-- 48 | Detail -->
## Creativity alone produces solutions looking for a problem

- An idea without a price cannot be ranked against the other ideas.
- "Put AI on it" is not a framing: it names a tool, not a lever or an owner.
- A clever lever owned by nobody on site will not survive your departure.
- Every idea goes back through the fork, the €447 and the assumptions table before it reaches a memo.


---
<!-- 49 | Framework -->
## Alternate the two modes in a loop, and always end on a number

1. **Observe.** Walk the floor, read the logs, listen to the people.
2. **Diverge.** Write many framings of the same leak.
3. **Measure.** Find the number that supports or kills each one.
4. **Reframe.** Use what the data said to sharpen or replace the framing.
5. **Size.** Price the survivors with the assumptions table.
6. **Choose.** One problem, one owner, one gain.


---
<!-- 50 | Framework -->
## Five moves to reframe a problem

- **Change the owner.** Ask how the planner, the operator and the sales director would each describe it.
- **Invert.** How would we make this leak twice as bad? The answer points at the cause.
- **Change the unit.** Per tonne, per changeover, per order, per shift: each unit shows a different pattern.
- **Borrow.** Who solves this problem elsewhere: a pit crew, an airline turnaround, a hospital ward?
- **Remove a constraint.** If changeovers were free, what would the plant do differently?


---
<!-- 51 | Detail -->
## The same Polymex changeover leak, framed four ways, gives four levers and four owners

| Framing | Lever | Owner |
|---|---|---|
| A setup problem: each changeover takes too long | SMED: move work outside the stop, standard tooling | Maintenance and shift leaders |
| A sequencing problem: the order of grades and colors forces long cleanings | Campaigns, light to dark, fewer transitions per week | Planning |
| A commercial problem: new retail clients send small, frequent orders | Minimum quantities, bundled orders, delivery windows | Sales director |
| A stock problem: high-runner grades are made to order | Make to stock for a few references, made in long runs | Supply chain and finance |

Source: Polymex operational annex, changeover count doubled since January with new retail clients.


---
<!-- 52 | Detail -->
## SMED itself came from a reframe, not from better measurement

- Shigeo Shingo did not time die changes more precisely. He split the work into what needs the machine stopped and what can be done while it runs.
- That one change of question took die changes from hours to minutes at Toyota.
- The analysis came afterwards: measure each task, move it outside the stop, verify.
- Expect the same order on your sites: a new question first, then the numbers that prove it.


---
<!-- 53 | Detail -->
## The creative half has rules too

- Write alone before anyone talks, so the first voice does not anchor the room.
- Quantity first: ten framings, then cut. The fourth one is usually better than the first.
- No judging while diverging. Pricing comes after, and it is ruthless.
- Bring someone who does not think like you: a technician, a planner, a salesperson.
- Timebox both halves. Seven minutes to diverge, seven to converge.


---
<!-- 54 | Detail -->
## A good reframe changes the lever or the owner, and it still has a price

- Same lever, same owner, new words: it is a synonym, not a reframe.
- A new lever with no owner on site: park it, and ask who could own it.
- A new lever and an owner, but no number: go back to the data before you go back to the client.
- A new lever, an owner and a price: it enters the leak register like any other row.


---
<!-- 55 | Exercise -->
## Exercise 3: frame one leak three ways and price each framing roughly

1. Pick one leak from yesterday: M04 at weekends, M02 or shift C.
2. Write alone for five minutes: as many framings as you can, using the five moves.
3. As a team, keep three that each change the lever or the owner.
4. For each, write the owner, the first number you would check and a rough size.

Fifteen minutes. One team reads out its most surprising framing.


---
<!-- 56 | Divider | ghost: € -->
## Part 5. Size in euros



---
<!-- 57 | Framework -->
## Size a leak in five moves, always in the same order

1. **Physical effect.** Hours, tonnes or kilos, with a source.
2. **Valuation path.** Which branch of the fork, which P&L line.
3. **Assumptions table.** Every number you did not measure.
4. **Low, base, high.** The driving assumption named in each case.
5. **Triangulate.** A second, independent path to the same number.



---
<!-- 58 | Detail -->
## The assumptions table is the deliverable; the point estimate is a by-product

| Assumption | Base | Range | Source | Who confirms |
|---|---|---|---|---|
| Contribution per tonne | €447 | €400 to €480 | P&L, controller | Mireille's controller |
| Sellable extra volume | 5,160 t a year | 0 to 5,160 t | Sales interview | Sales director, in writing |
| SMED reduction of changeover time | 40% | 30 to 50% | Benchmark | Maintenance and Marc |
| Share of overtime avoidable | 30% | 0 to 50% | Overtime by day of week | HR and Hervé |



---
<!-- 59 | Framework -->
## Inventory releases cash once and saves carrying cost every year: never add the two

| Effect | Example: cut €10M of inventory |
|---|---|
| Cash released | €10M, once, in the year the stock goes down |
| Carrying cost saved | About €1.8M a year at 18%: capital, space, obsolescence, shrink |
| What you must never write | "€11.8M of savings" |



---
<!-- 60 | Detail -->
## Triangulate every big number, and treat a disagreement as a finding

- Two independent paths within 20 to 30% of each other: present with confidence.
- Further apart: you have found an error or a hidden assumption.
- Polymex example: the annex reports changeovers at 11.5% of scheduled hours; the extrusion logs say 8.8% for the quarter and 10.3% in March.
- Same plant, different perimeter and period. Ask the controller which one finance trusts before you price anything on it.

Source: Polymex operational annex; extrusion shift logs, Q1 2026.



---
<!-- 61 | Divider | ghost: NET -->
## Part 6. Choose the problem worth the change


---
<!-- 62 | Framework -->
## A problem is worth solving when it is big, measurable, controllable, owned and urgent

- **Big.** Worth at least ten times what it costs to fix, the change included.
- **Measurable.** The controller can compute the gain without you.
- **Controllable.** The plant holds the lever; corporate pricing does not count.
- **Owned.** A named person will change how they work.
- **Urgent.** Someone can say why now, in one sentence.



---
<!-- 63 | Framework -->
## Place every candidate on gain against change load before you rank it

- **Big gain, heavy change.** Where FDE work earns its fee. Plan the change from day one.
- **Big gain, light change.** Rare. Check twice why nobody has done it already.
- **Small gain, light change.** Fine as a first proof, only if the controller signs it.
- **Small gain, heavy change.** Never. It burns the sponsor and the people you need for the next problem.


---
<!-- 64 | Framework -->
## Rank candidates on five scores, and net the change out of the gain

| Score | The question |
|---|---|
| Net gain | Euros a year after the cost of change, signed by the controller |
| Confidence | How many of the assumptions are measured, not estimated? |
| Change load | How many people change how they work, and how much? |
| Time to signed gain | Can finance book it within ninety days? |
| Reuse | Do the next three use cases run on the same data? |


---
<!-- 65 | Framework -->
## One plant becomes an account in four steps: land, prove, replicate, expand

1. **Land.** One site, one problem, one sponsor.
2. **Prove.** A gain the client's controller signs.
3. **Replicate.** The same ontology and pipeline at a sister site, in half the time.
4. **Expand.** The next problem, on data you already cleaned.



---
<!-- 66 | Detail -->
## Choose the first problem for what it unlocks, not only for its size

- A gain finance can sign within ninety days beats a bigger one it cannot measure.
- Prefer the problem whose data foundation the next three use cases reuse.
- Prefer a problem that turns a user into a champion, not one that threatens her job.
- Stay clear of a political minefield in the first month, even if it is the biggest leak.



---
<!-- 67 | Detail -->
## Map the account before you map the plant

| Question | Why it matters |
|---|---|
| Who owns the budget, site or group? | Decides who signs the next phase |
| What else is in flight: lean program, APS selection, ERP upgrade? | Your gain may already be claimed by someone else |
| How many sister sites run the same process? | The size of the prize if you replicate |
| Who has tried before, and what happened? | The scar tissue you will inherit |
| What does the director's boss measure him on? | His real "why now" |



---
<!-- 68 | Detail -->
## Write down the problems you kill, and why

- A kill list shows the sponsor you looked at everything, not only at your favorite.
- It protects you when someone asks in month three why you did not do the obvious thing.
- It is the backlog for the next phase, already sized.
- One line each: the problem, its rough size, the reason it lost.


---
<!-- 69 | Divider | ghost: LAB -->
## Lab: price the leaks you found yesterday



---
<!-- 70 | Exercise -->
## Exercise 4: price every leak, net the change, write the memo for Hervé

1. Fill the leak register: the five leaks from the logs, plus what the P&L and annex reveal.
2. Value each leak with the fork, the €447 per tonne and the assumptions table.
3. Flag every double count and every number the controller must confirm.
4. For each leak, name who must change and how heavy the change is.
5. Rank the three biggest recurring leaks worth their change; state cash effects separately.
6. Write the one-page memo for Hervé: answer first, three leaks, one question each, the kill list.

Thirty-five minutes. Builder keeps the register in code or a spreadsheet; Verifier recomputes the top three independently.


---
<!-- 71 | Detail -->
## The register: one row per leak, ten columns, nothing hidden

| Column | Content |
|---|---|
| Leak and family | M07 micro-stops, unplanned downtime |
| Evidence | The number, its source and period |
| Physical effect | Tonnes or hours a year, annualized and labeled as such |
| Valuation path | Which branch of the fork, which P&L line |
| Low, base, high | In € a year, with the driving assumption |
| Recurring or one-time | Stated separately, never summed |
| Overlaps | Which other row counts the same tonne |
| Confidence | High, medium, low, and why |
| Change required | Who works differently, and how heavy: light, medium, heavy |
| First question on site | To whom, and what answer would change the number |



---
<!-- 72 | Detail -->
## Demo in three minutes: the three leaks, who changes, the assumption you would test first

1. Your three biggest recurring leaks, in euros a year, with ranges.
2. How you handled the demand fork, in one sentence.
3. Who has to work differently for your top leak.
4. The double count you found, and one problem you killed.
5. The one assumption that moves your total most, and who confirms it.


---
<!-- 73 | Detail -->
## Five things to keep from this morning

1. Change management is downstream of the problem. A problem that never becomes a gain is meaningless.
2. Change costs about the same whatever the prize, so only a big problem pays for it.
3. Analysis finds the leak, imagination finds the lever. Alternate the two and end on a number.
4. Value a freed hour with the fork, and one more tonne at its contribution margin.
5. The assumptions table, a range and a second path are what make a number credible.


---
<!-- 74 | Detail -->
## Go further, and this afternoon

**Read**
- Eliyahu Goldratt, *The Goal*: the constraint, as a novel.
- Wallace Hopp and Mark Spearman, *Factory Physics*: why queues and variability eat capacity.
- Charles Conn and Robert McLean, *Bulletproof Problem Solving* (2018): sizing and triangulation.
- Shigeo Shingo, *A Revolution in Manufacturing: The SMED System* (1985): the reframe behind fast changeovers.
- John Kotter, *Leading Change* (1996): what change asks of an organization.

**This afternoon**
- Leading an FDE project: the six-phase method, the charter, governance and the gains validation protocol.
